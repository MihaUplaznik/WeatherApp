import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { map, tap, take, exhaustMap } from 'rxjs/operators';

//import { Izposoja } from './izposoja.model';
import { AuthService } from './auth/auth.service';
//import { IzposojaService } from './izposoja.service';
import { WeatherService } from './services/weather.service';
import { Mesto } from './models/city';

@Injectable({ providedIn: 'root' })
export class DataStorageService {
  constructor(
    private http: HttpClient,
    private forecastService: WeatherService,
    private authService: AuthService
  ) {}

  storeRecipes() {
    const forecast = [this.forecastService.mestoToday, this.forecastService.mestoTomorrow, this.forecastService.mestoAfterTomorrow, this.forecastService.mestoThreeDays ];
    this.http
      .put(
        'https://auth-vremenska-app.firebaseio.com/forecast.json?auth=' +
        ((localStorage.getItem('token') !== null && localStorage.getItem('token') !== '') ?
        localStorage.getItem('token') : ''),
        forecast
      )
      .subscribe(response => {
        console.log(response);
      });
  }

  fetchRecipes() {
    return this.http
      .get<Mesto[]>(
        'https://auth-vremenska-app.firebaseio.com/forecast.json?auth=' + 
        ((localStorage.getItem('token') !== null && localStorage.getItem('token') !== '') ?
        localStorage.getItem('token') : '')
      )
      .pipe(
        map(forecastCity => {
          return forecastCity.map(city => {
            return {
              ...city
            };
          });
        }),
        tap(forecastCity => {
          this.forecastService.getForecastByName( forecastCity[0].name );
        })
      );
  }
}

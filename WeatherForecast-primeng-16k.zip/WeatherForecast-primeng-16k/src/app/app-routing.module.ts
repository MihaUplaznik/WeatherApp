import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { RegisterComponent } from './auth/register/register.component';
import { RetrieveComponent } from './auth/retrieve/retrieve.component';
import { SigninComponent } from './auth/signin/signin.component';
import { WeatherForecastItemComponent } from './components/weather-forecast/weather-forecast-item/weather-forecast-item.component';
import { WeatherForecastComponent } from './components/weather-forecast/weather-forecast.component';
import { WeatherForecastItemWholedayComponent } from './components/weather-forecast-item-wholeday/weather-forecast-item-wholeday.component';



const routes: Routes = [
  { path: '', redirectTo: 'signin', pathMatch: 'full' },
  {path: 'weather', component: WeatherForecastComponent},
  {path: 'detail', component: WeatherForecastItemComponent },
  { path: 'signup', component: RegisterComponent },
  { path: 'signin', component: SigninComponent },
  { path: 'retrieve', component: RetrieveComponent },
  { path: 'detail/wholeday/:idname/:page', component: WeatherForecastItemWholedayComponent },
  { path: '**', redirectTo: 'weather' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

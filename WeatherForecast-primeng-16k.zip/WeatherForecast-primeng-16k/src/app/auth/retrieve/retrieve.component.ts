import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { of } from 'rxjs';
import { TranslateService } from '@ngx-translate/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-retrieve',
  templateUrl: './retrieve.component.html',
  styleUrls: ['./retrieve.component.css']
})
export class RetrieveComponent implements OnInit {

  constructor(private router: Router,
            public authService: AuthService,
            private translateService: TranslateService) { }

  ngOnInit() {
  }


  onRetrieve(emailRef: NgForm) {
    this.router.navigate(['/retrieve']);
    // to do
    this.authService.retrieveEmail(emailRef.form.value.email_).then(
      (val) => {
        this.router.navigate(['/signin']);
      },
      (err) => {
        this.authService.error = true;
        this.authService.errorStr = this.translateService.instant("errregister");
        return of('error');
      }
    );;

  }


}

import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';
import { of } from 'rxjs';


@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit {
//  error = false;
//  errorStr: string = null;

  constructor(public authService: AuthService,
        private router: Router) { }

  ngOnInit() {
    if (localStorage.getItem('token') !== null) {
      this.router.navigate(['/weather']);
    }
    this.authService.error = false;
    this.authService.errorStr = '';
  }

  onSignin(form: NgForm) {
    // Register
    const email = form.value.email;
    const password = form.value.password;
    let allow: boolean = this.borgThePass(password);
    if (!allow) {
      this.authService.error = true;
      this.authService.errorStr = "error signin" + ", invalid PASSWORD";
      console.log(allow);
      return;
    }
    console.log("valid pass");

    this.authService.signinUser(email, password).then(
      (val) => {
        this.router.navigate(['/weather']);
        return of('done');
      },
      (err) => {return of('error');}
    );

  }

  onRetrieve(emailRef: HTMLElement) {
    this.router.navigate(['/retrieve']);
  }

  onLogout() {
    this.authService.logoutUser();
    localStorage.removeItem('token');
    localStorage.removeItem('cities');
  }


  borgThePass(passw: string): boolean {
    let indabc = -1;
    // letter, črka
    for (let ia = 0; ia < passw.length ; ia++) {
      if ( passw.charAt(ia).toLocaleUpperCase() !== passw.charAt(ia) ) {
        indabc = ia;
        break;
      }
    }
    let indABC = -1;
    // capital letter, velika črka
    for (let iA = 0; iA < passw.length; iA++) {
      if ( passw.charAt(iA).toLocaleLowerCase() !== passw.charAt(iA) ) {
        indABC = iA;
        break;
      }
    }
    let ind123 = -1;
    // number, cifra
    for (let i1 = 0; i1 < passw.length; i1++) {
      if ( passw.charAt(i1) === '0'
        || passw.charAt(i1) === '1'
        || passw.charAt(i1) === '2'
        || passw.charAt(i1) === '3'
        || passw.charAt(i1) === '4'
        || passw.charAt(i1) === '5'
        || passw.charAt(i1) === '6'
        || passw.charAt(i1) === '7'
        || passw.charAt(i1) === '8'
        || passw.charAt(i1) === '9' )
      {
        ind123 = i1;
        break;
      }
    }
    let ind_$ = -1;
    // določeni simbol
    if ( passw.includes("-") || passw.includes("_")
      || passw.includes("@")
      || passw.includes("!") || passw.includes("?") || passw.includes(".") || passw.includes(",")
      || passw.includes(";") || passw.includes(":")
      || passw.includes("$") || passw.includes("€") || passw.includes("--")
      || passw.includes("+") || passw.includes("-")
      || passw.includes("*") || passw.includes("/") || passw.includes("%")
      || passw.includes("&") || passw.includes("^") || passw.includes("|")
      || passw.includes("÷") || passw.includes("×")
      || passw.includes("ß") || passw.includes("¤")
      || passw.includes("¨") || passw.includes("¸") || passw.includes("~")
      || passw.includes("\"") || passw.includes("\\") || passw.includes("'")
      || passw.includes("ˇ") || passw.includes("˘") || passw.includes("°")
      || passw.includes("˛") || passw.includes("`") || passw.includes("˙")
      || passw.includes("˝") || passw.includes("¨") || passw.includes("¸")
      ) {
      ind_$ = 2;
    }

    console.log("a "+ indabc + ", A " + indABC + ", 1 " + ind123 + ", $ " + ind_$);
    if (indabc > -1
      && ( indABC === -1 || indABC > -1 )
      && ind123 > -1
      ) {
      if (ind_$ === -1) {
        this.authService.errorStr= "manjka simbol";
        this.authService.error = false;
        return true;
      }
      return true;
    } else {
      return false;
    }

  }

}

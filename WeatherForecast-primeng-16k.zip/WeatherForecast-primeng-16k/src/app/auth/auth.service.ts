import { Injectable } from '@angular/core';
import * as firebase from 'firebase/auth';
import * as firebaseapp from 'firebase/app';
import { throwError } from 'rxjs';
import { TranslateService } from '@ngx-translate/core';
import { IdTokenResult, User } from 'firebase/auth';

@Injectable()
export class AuthService {
    sucess: boolean;
    error: boolean;
    email: string;
    password: string;
    errorStr: string;
    token: string;
    promise: Promise<any>;
    public jezik: string;

    constructor(private translateService: TranslateService) {
      this.sucess = false;
      this.error = false;
      this.email = '123';
      this.password = '123';
      this.errorStr = 'no error';
      this.token = 'emptytoken';
      this.promise = new Promise((resolve, reject) =>{ return null;});
      this.jezik = 'sl';

    }

    registerUser(email: string, password: string) {
        // register in firebase
        this.promise = new Promise<string>((resolve, reject) => {
        firebase.createUserWithEmailAndPassword(firebase.getAuth(), email, password)
        .then(
           (promiseUserCredential) => {
//           (response) => {
               this.error = false;
               this.errorStr = '';
               console.log('ok registered' );
               console.log(promiseUserCredential.user);
               resolve('ok' + promiseUserCredential.user);
           }
        ).catch(
            () => {
//            (error) => {
                this.error = true;
                this.errorStr = this.translateService.instant("errregister"); //"Wrong Signin. " + error;
                reject(this.errorStr);
            }
        );
        });
        return this.promise;
    }

    signinUser(email: string, password: string) { // : Promise<string>
                                                // | Promise<firebase.auth.UserCredential>
                                                // | void {
        this.email = email;
        this.promise = new Promise<string>((resolve, reject) => {
            firebase.signInWithEmailAndPassword(firebase.getAuth(), email, password)
//            firebase.getAuth().signInWithEmailAndPassword(email, password)
            .then(
                (promiseUserCredential) => {
                    // update user
                    firebase.updateCurrentUser(firebase.getAuth(), promiseUserCredential.user);
                    // save token prefereably
                    firebase.getIdToken( promiseUserCredential.user)
                        .then(
                            (token: string) => {
                                this.error = false;
                                this.errorStr = '';
                                this.sucess = true;
                                this.token = token; this.sucess = true;
                                localStorage.setItem('token', this.token);
                                console.log('user token' );
                                console.log(promiseUserCredential.user);
                                console.log(this.token);
                                resolve(this.token);
                            }
                        )
                }
            )
            .catch(
//                error => {
                () => {
                    this.sucess = false;
                    this.error = true;
                    this.errorStr = this.translateService.instant("errsignin"); //"Wrong Signin. " + error;
                    localStorage.removeItem('token');
                    reject(this.errorStr);
                }
            );

        });
        return this.promise;
    }


    retrieveEmail(email: string) {
        this.email = email;
        this.promise = new Promise<void>(
            (resolve, reject) => {
                firebase.sendPasswordResetEmail(firebase.getAuth(), this.email).then(
//                    response => {
                () => {
                      resolve();
                    }
                ).catch(
//                    error => {
                    () => {
                        this.sucess = false;
                        this.error = true;
                        this.errorStr = this.translateService.instant("errregister");
                        localStorage.removeItem('userData');
                        localStorage.removeItem('email');
                        reject(this.errorStr);
                    }
                );
            }
        );

        return this.promise;
    }


    getEmail() {
        //this.email = firebase.auth().currentUser.email;
        localStorage.setItem('email', this.email);
        return this.email;
    }

    getIdToken() {
        if (localStorage.getItem('token') !== null) {
            localStorage.removeItem('token');
            //return this.token;
        }
        let user: firebase.User | null = null;
        if ( firebase.getAuth().currentUser != null) {
          user = firebase.getAuth().currentUser;
        }
        else {
          if (this.email !== '' && this.email !== '123') {
            this.signinUser(this.email, this.password);
            user = firebase.getAuth().currentUser;
         }

        }
        if (user !== null) {
/*        firebase.getIdTokenResult( user )
//        firebase.auth().currentUser .getIdToken()
            .then(
                (token: IdTokenResult) => {
                    this.token = token.token;
                    localStorage.setItem('token',  token.token);
                    this.sucess = true;
//                    resolve( this.token );
                }
             );*/
            user.getIdToken().then(
              (token) => {
                this.token = token;
              }
            );
        }
        else {
          console.log('ni tokena');
//          this.signinUser(this.email, this.password);
        }
    }

    logoutUser() {
        firebase.getAuth().signOut();
        localStorage.removeItem('token');
        localStorage.removeItem('email');
        this.email = '123';
        this.password = '123';
//        localStorage.removeItem('cities');
        this.token = '';
        this.sucess = false;
        this.error = false;
        this.errorStr = 'no error';
    }

    isAuthenticated() {
        this.token = localStorage.getItem('token') || '';
        return (this.token !== null) && (this.token !== '');
    }
}

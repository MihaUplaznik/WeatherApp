export class WeatherForecastModel {
  cityName: string;

  constructor(cityName: string) {
    this.cityName = cityName;

    /**
     * TODO this is example data, you should use your own properties
     **/
  }
}

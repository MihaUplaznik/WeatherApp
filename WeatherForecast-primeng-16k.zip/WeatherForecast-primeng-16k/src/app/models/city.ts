export class Mesto {
  constructor(
    public email: string,
    public name: string,
    public temp: string,
    public feels_like: string,
    public weather: string,
    public humidity: number,
    public description: string,
    public windspeed: number,
    public visibility: string) {
  }
}

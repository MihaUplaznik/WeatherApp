import {Component} from '@angular/core';
import * as firebaseapp from 'firebase/app';
import * as firebaseauth from 'firebase/auth';
import { AuthService } from './auth/auth.service';
import { DataStorageService } from './data-storage.service';
import { WeatherService } from './services/weather.service';
import { Color } from 'chart.js';
import { TranslateService } from '@ngx-translate/core';

/**
 * additional functions are deascribed on page
 * https://primeng.org/chart
 * and besides   use or dont use --save
npm install chart.js 
npm install primeng 
npm install bootstrap@3
npm install @ngx-translate @ngx-translate/http-loader @ngx-translate/core
npm install firebase @angular/fire
 *
@ngx-translate/http-loader: A loader for loading translation files from a remote HTTP server.
@ngx-translate/browser-loader: A loader for loading translation files from the browser's local storage.
 * and then
 * adjust angular.json like the bootstrap
 * and import the modules
 *
 * and then start html-ing the templates
 */
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  showTemplate = true;
  lang: string = 'en';

  constructor(protected authService: AuthService,
      private forecastService: WeatherService,
      private translate: TranslateService,
      private dataStorageService: DataStorageService) {
    firebaseapp.initializeApp({
      apiKey: "AIzaSyA-0im8wOi5xJjd38OmXCrrAjql9pW8MTQ",
      databaseURL: "https://auth-vremenska-app.firebaseio.com"
    });
    translate.setDefaultLang('sl');
    this.lang = 'sl';
  
  }


  public jezik: string = 'sl';
  mesto = 'Weather location';
  registriraj = 'Register';
  prijava = 'Login';
  odjava = 'Logout';
  jezi = 'English';
  
  clickToggle: boolean = false;
  doToggle() {
    this.clickToggle = !this.clickToggle;
  }


  onSelectEnglish() {
    this.lang = 'en';
    this.translate.use(this.lang);
  }
  onSelectSlovenian() {
    this.lang = 'sl';
    this.translate.use(this.lang);
  }
  
  ngOnInit() {
    if (localStorage.getItem('jezik') ) {
      this.jezik = localStorage.getItem('jezik') || 'en';
      this.authService.jezik = this.jezik;
    } else {
      this.jezik = 'sl';
      this.authService.jezik = 'sl';
      localStorage.setItem('jezik', 'sl');
    }

    this.Page_Load([], null);
  }

  onLogout() {
    this.authService.logoutUser();
    // vprasanje je ali naj prav tako izbrisemo mesta
    this.authService.token = '';
    this.authService.sucess = false;
  }

  // nepotrebna nastavitev jezika
  onJezik(localization: string) {
    localStorage.setItem('jezik', localization);
    this.jezik = localization;
    this.authService.jezik = localization;
  }

  onSaveData() {
    this.forecastService.mestoToday.name = this.forecastService.mestoToday.name !== '' ? this.forecastService.mestoToday.name : 'Šempeter v Savinjski Dolini';

    this.dataStorageService.storeRecipes();

    localStorage.setItem('city',
    JSON.stringify(this.forecastService.mestoToday));
    console.log('save data'+ this.forecastService.mestoToday );
  }

  onFetchData() {
    this.dataStorageService.fetchRecipes().subscribe();
    console.log('Fetched data.');
  }


  lblMsgText: string = '';
  Page_Load(request : [], e : Event | null) {
    this.lblMsgText = "Hello, Browser!"
  }

  lblMsgForeColor: string = 'background-color: orange'; 
  btnBlack_Click(request: [], E? : Event | null) {
    this.lblMsgForeColor = 'Black';
  }


  btnGreen_Click(request : [], E? : Event | null) {
    this.lblMsgForeColor = 'Green';
    this.Page_Load([], null);

  }

  btnBlue_Click(request: [], E? : Event | null) {
    this.lblMsgForeColor = 'Blue';
  }

  btnBlack_Click2() {
    this.lblMsgForeColor = 'black';
    return this.lblMsgForeColor;
  }

  btnGreen_Click2() {
    this.lblMsgForeColor = 'green';
    return this.lblMsgForeColor;
  }

  btnBlue_Click2() {
    this.lblMsgForeColor = 'blue';
    return this.lblMsgForeColor;
  }

}

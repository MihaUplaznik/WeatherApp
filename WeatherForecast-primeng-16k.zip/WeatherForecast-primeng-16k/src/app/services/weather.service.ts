import {Injectable, OnInit} from '@angular/core';
import {WeatherForecastModel} from '../models/weather-forecast.model';
import {HttpClient} from '@angular/common/http';
import { map, Subject, switchAll, switchMap, take, timestamp } from 'rxjs';
import { Mesto } from '../models/city';

export class WeatherForecast2 {
  mesto: Mesto = new Mesto('test@emg.si', 'Maribor', '20°C',
  '21°C', 'cloudy', 20, 'cloudy', 2.5, '10000');;
  error: boolean = false;
  errorStr: string = '';
  isSubmited: boolean = false;

  mestoToday: Mesto = new Mesto('test@emg.si', 'Maribor', '20°C',
  '24', 'cloudy', 20, 'cloudy', 2.5, '10000');
  mestoTomorrow: Mesto = new Mesto('test@emg.si', 'Maribor', '20°C',
  '24', 'cloudy', 20, 'cloudy', 2.5, '10000');
  mestoAfterTomorrow: Mesto = new Mesto('test@emg.si', 'Maribor', '20°C',
  '24', 'cloudy', 20, 'cloudy', 2.5, '10000');
  mestoThreeDays: Mesto = new Mesto('test@emg.si', 'Maribor', '20°C',
  '24', 'cloudy', 20, 'cloudy', 2.5, '10000');
  mestoFourDays: Mesto = new Mesto('test@emg.si', 'Maribor', '20°C',
  '24', 'cloudy', 20, 'cloudy', 2.5, '10000');
  mestoTodayMin: Mesto = new Mesto('test@emg.si', 'Maribor', '20°C',
  '24', 'cloudy', 20, 'cloudy', 2.5, '10000');
  mestoTomorrowMin: Mesto = new Mesto('test@emg.si', 'Maribor', '20°C',
  '24', 'cloudy', 20, 'cloudy', 2.5, '10000');
  mestoAfterTomorrowMin: Mesto = new Mesto('test@emg.si', 'Maribor', '20°C',
  '24', 'cloudy', 20, 'cloudy', 2.5, '10000');
  mestoThreeDaysMin: Mesto = new Mesto('test@emg.si', 'Maribor', '20°C',
  '24', 'cloudy', 20, 'cloudy', 2.5, '10000');
  mestoFourDaysMin: Mesto = new Mesto('test@emg.si', 'Maribor', '20°C',
  '24', 'cloudy', 20, 'cloudy', 2.5, '10000');

  dateToday: Date = new Date();
  dateTomorow: Date = new Date();
  dateAfterTomorrow: Date = new Date(); 
  dateThreeDays: Date = new Date();
  dateFourDays: Date = new Date();
  isSnowRainToday: boolean = false;
  isSnowRainTomorow: boolean = false;
  isSnowRainAfterTomorow: boolean = false;
  isSnowRainThreeDays: boolean = false;
  isSnowRainFourDays: boolean = false;
  snowRainToday: string = '0mm';
  snowRainTomorow: string = '0mm';
  snowRainAfterTomorow: string = '0mm';
  snowRainThreeDays: string = '0mm';
  snowRainFourDays: string = '0mm';
  bSnowRainToday: number = 0;
  bSnowRainTomorow: number = 0;
  bSnowRainAfterTomorow: number = 0;
  bSnowRainThreeDays: number = 0;
  bSnowRainFourDays: number = 0;
  minDan: number = 8.15;
  maxDan: number = 16.10;
  danasnjaDolzinaDneva: number = 0;

  responseQuery: any | null = null; 
  data: any | null = null;
  options: any | null = null; 

  clickToggle: boolean = false;
}

@Injectable({
  providedIn: 'root'
})
export class WeatherService implements OnInit {
  isSubmited: boolean = false;
  mesto: Mesto = new Mesto('test@emg.si', 'Maribor', '20°C',
          '21°C', 'cloudy', 20, 'cloudy', 2.5, '10000');
  error: boolean = false;
  errorStr: string = '';
  date: Date = new Date();
  mestoToday: Mesto = new Mesto('test@emg.si', 'Maribor', '20°C','24', 'cloudy', 20, 'cloudy', 2.5, '10000');
  mestoTomorrow: Mesto = new Mesto('test@emg.si', 'Maribor', '20°C',
  '24', 'cloudy', 20, 'cloudy', 2.5, '10000');
  mestoAfterTomorrow: Mesto = new Mesto('test@emg.si', 'Maribor', '20°C',
  '24', 'cloudy', 20, 'cloudy', 2.5, '10000');
  mestoThreeDays: Mesto = new Mesto('test@emg.si', 'Maribor', '20°C',
  '24', 'cloudy', 20, 'cloudy', 2.5, '10000');
  mestoFourDays: Mesto = new Mesto('test@emg.si', 'Maribor', '20°C',
  '24', 'cloudy', 20, 'cloudy', 2.5, '10000');
  mestoTodayMin: Mesto = new Mesto('test@emg.si', 'Maribor', '20°C',
  '24', 'cloudy', 20, 'cloudy', 2.5, '10000');
  mestoTomorrowMin: Mesto = new Mesto('test@emg.si', 'Maribor', '20°C',
  '24', 'cloudy', 20, 'cloudy', 2.5, '10000');
  mestoAfterTomorrowMin: Mesto = new Mesto('test@emg.si', 'Maribor', '20°C',
  '24', 'cloudy', 20, 'cloudy', 2.5, '10000');
  mestoThreeDaysMin: Mesto = new Mesto('test@emg.si', 'Maribor', '20°C',
  '24', 'cloudy', 20, 'cloudy', 2.5, '10000');
  mestoFourDaysMin: Mesto = new Mesto('test@emg.si', 'Maribor', '20°C',
  '24', 'cloudy', 20, 'cloudy', 2.5, '10000');
  latitude: number = 46.5576439; //0;
  longitude: number = 15.6455854; //0;
  country: string = 'ZZ';
  countWeatherTimes: number = 0;
  weatherToday: Date = new Date();
  interval : any = '';

  dateToday: Date = new Date();
  dateTomorow: Date = new Date();
  dateAfterTomorrow: Date = new Date();
  dateThreeDays: Date = new Date();
  dateFourDays: Date = new Date();
  isSnowRainToday: boolean = false;
  isSnowRainTomorow: boolean = false;
  isSnowRainAfterTomorow: boolean = false;
  isSnowRainThreeDays: boolean = false;
  isSnowRainFourDays: boolean = false;
  snowRainToday: string = '0mm';
  snowRainTomorow: string = '0mm';
  snowRainAfterTomorow: string = '0mm';
  snowRainThreeDays: string = '0mm';
  snowRainFourDays: string = '0mm';
  bSnowRainToday: number = 0;
  bSnowRainTomorow: number = 0;
  bSnowRainAfterTomorow: number = 0;
  bSnowRainThreeDays: number = 0;
  bSnowRainFourDays: number = 0;
  minDan: number = 8.15;
  maxDan: number = 16.10;
  danasnjaDolzinaDneva: number = 0;

  responseQuery: any | null = null;
  weatherForecast2: WeatherForecast2[] = []; 

  // Kvsej tej logiki damo Subject
  // in vsak subscribe premaknemo v Weather komponenti
  thisSubj: Subject<boolean> = new Subject<boolean>();

  constructor(public httpClient: HttpClient) {
    if ( localStorage.getItem('weather-times') === ''
    || localStorage.getItem('weather-times') === null
    || localStorage.getItem('weather-times') === undefined )
    {
      localStorage.setItem('weather-times', '1' );
      localStorage.setItem( 'weather-date', (new Date()).toLocaleDateString() );
    }
    let countT = ( (localStorage.getItem('weather-times') !== null) ? localStorage.getItem('weather-times') : 1);

    let today = ( localStorage.getItem('weather-date') !== null ) ?
      new Date (Date.parse( localStorage.getItem('weather-date') || '1677200500') ) : new Date();
    this.countWeatherTimes = +(countT || '1');
    this.weatherToday = today;

    this.init();
    this.getQuery("Ljubljana");
  }

  ngOnInit() {
//    this.getForecast();
//      this.pushNewWeatherForecast();
  }

  /**
   * TODO Get weather forecast data from the following API:
   * Example: https://www.weatherapi.com/api-explorer.aspx#forecast
   * API key: a83bd642f1ce4fd88a494018221212
   **/
  getWeatherForecastForCity(cityName: string): WeatherForecastModel {
    return new WeatherForecastModel(cityName);
  }

  getQuery(mesto: string) {
    if (mesto === null) {
      mesto = 'Maribor';
    }
    if (mesto.indexOf(',') > 0) {
      mesto = mesto.substring(0, mesto.indexOf(','));
    }

    /*
    this.httpClient.get('http://api.openweathermap.org/geo/1.0/direct?q=' + mesto + '&limit=5&appid=fbd2befb1c3fa8f6f4343af5666d6150'
    )
    .pipe( map(
        // bindamo response v objekt
        (response: any) => {
            console.log(response);
            this.isSubmited = true ;

            this.mesto.name = mesto;
            this.date = new Date();
            this.isSubmited = false;

            this.latitude = response[0].lat;
            this.longitude = response[0].lon;
            this.country = response[0].country;

            return response;
        }
    ) )
    .subscribe(
      (response) => {
        // bindamo response v objekt
        console.log(response);
        this.isSubmited = true ;

        this.date = new Date();
        this.isSubmited = false;

        this.latitude = response[0].lat;
        this.longitude = response[0].lon;
        this.country = response[0].country;

        console.log(' lan, lat imamo 3 '+ this.latitude + ', ' + this.longitude);

//        this.getForecast();

        return null;
      }
    );
    */
    // Retrieve Geolocation First
    this.getForecastByGeolocation();
  }


  getForecastByName(name: string) {

    this.countWeatherTimes += 1;
    console.log('start' + ',,, counter ,,,' + this.countWeatherTimes);

    localStorage.setItem('weather-times', JSON.stringify(this.countWeatherTimes) );
    let date2 = new Date (localStorage.getItem( 'weather-date') || (new Date()).getMilliseconds());

    if (this.countWeatherTimes * 40 > 948 || this.countWeatherTimes * 40 <= 0) {
      this.isSubmited = true;
      if (this.date === date2) {
        this.countWeatherTimes = 25;
        console.log('for today you re out');

        return;
      } else {
        let date3 = ( date2.getDate() < this.date.getDate() ) ? this.date : date2;
        localStorage.setItem( 'weather-date', date3.toLocaleDateString() );
        this.date = date3;
        console.log('resetting startin it today, ' + '0');
        this.countWeatherTimes = 0;
        localStorage.setItem('weather-times', JSON.stringify(this.countWeatherTimes) );

        return;
      }
    }

    let tmpName = 'Ljubno';
    if (name === null || name === '' || name === undefined ) {
      tmpName = 'Maribor';
    }
    else if (name.includes(',')) {
      tmpName = name.substring(0, name.indexOf(',')) + ',' + ( name.substring(name.indexOf(',') + 1, name.length) ).toLowerCase() ;
    } else {
      tmpName = name;
    }

    console.log('start' + ',,, counter ,,,' + this.countWeatherTimes + ', '+ tmpName);

    this.interval = setInterval( () => {
    this.httpClient.get('https://api.openweathermap.org/data/2.5/forecast?q='
      + tmpName + '&appid=fbd2befb1c3fa8f6f4343af5666d6150'
      )
      .pipe( map(
          // bindamo response v objekt
          // Put metoda ima New Razrede, da dobimo nove podatke iz pomnilnika
          (response: any) => {
              console.log(' forecast je ');
              console.log(response);

              // we need query
              this.responseQuery = response;

              // obvestimo da je sprememba v osnovnem getNapoved(name) servicu
              let ind1 = 0;
              let ind1min = 0;
              let ind2 = 8;
              let ind2min = 8;
              let ind3 = 14;
              let ind3min = 14;
              let ind4 = 22;
              let ind4min = 22;
              let ind5 = 30;
              let ind5min = 30;
              for (let i = 0; i < 40; i++) {
                if ((response.list[i].dt_txt).indexOf('3:00:00') > 0 && i < 8) {
                  ind1min = i;

                  continue;
                } else if ((response.list[i].dt_txt).indexOf('12:00:00') > 0 && i < 8) {
                  this.izracunajDanasnjiDan( new Date() );
                  ind1 = i;

                  continue;
                } else if ((response.list[i].dt_txt).indexOf('3:00:00') > 0 && i < 16 && i >= 8) {
                  ind2min = i;

                  continue;
                } else if ((response.list[i].dt_txt).indexOf('12:00:00') > 0 && i < 16 && i >= 8) {
                  ind2 = i;

                  continue;
                } else if ((response.list[i].dt_txt).indexOf('3:00:00') > 0 && i < 24 && i >= 16) {
                  ind3min = i;

                  continue;
                } else if ((response.list[i].dt_txt).indexOf('12:00:00') > 0 && i < 24 && i >= 16) {
                  ind3 = i;

                  continue;
                } else if ((response.list[i].dt_txt).indexOf('3:00:00') > 0 && i < 32 && i >= 24) {
                  ind4min = i;

                  continue;
                } else if ((response.list[i].dt_txt).indexOf('12:00:00') > 0 && i < 32 && i >= 24) {
                  ind4 = i;

                  continue;
                } else if ((response.list[i].dt_txt).indexOf('3:00:00') > 0 && i < 40 && i >= 32) {
                  ind5min = i;

                  continue;
                } else if ((response.list[i].dt_txt).indexOf('12:00:00') > 0 && i < 40 && i >= 32) {
                  ind5 = i;

                  break;
                }
              }

              this.mestoTodayMin = new Mesto('test@emg.si', 'Maribor', '20°C','24', 'cloudy', 20, 'cloudy', 2.5, '10000');
              this.mestoToday = new Mesto('test@emg.si', 'Maribor', '20°C','24', 'cloudy', 20, 'cloudy', 2.5, '10000');
              this.mestoTodayMin.name = response.city.name;
              this.mestoTodayMin.temp = (response.list[ind1min].main.temp - 273.16).toFixed(1); // Name ()
              this.mestoTodayMin.humidity = +response.list[ind1min].main.humidity;
              this.mestoToday.name = response.city.name;
              this.mestoToday.temp = (response.list[ind1].main.temp - 273.16).toFixed(1); // Name ()
              this.mestoToday.feels_like = (response.list[ind1].main.feels_like - 273.16).toFixed(1);
              this.mestoToday.weather = response.list[ind1].weather[0].main;
              this.mestoToday.humidity = +response.list[ind1].main.humidity;
              this.mestoToday.description = response.list[ind1].weather[0].description;
              this.mestoToday.windspeed = (response.list[ind1].wind.speed).toFixed(1);
              this.mestoToday.visibility = response.list[ind1].visibility;
              this.dateToday = new Date( response.list[ind1].dt_txt );
              if ( response.list[ind1].snow !== undefined) {
                this.isSnowRainToday = true;
                let tmpMM: string = response.list[ind1].snow[ "3h" ];
                this.snowRainToday = 'snowing' + tmpMM + ' lit/m2';
                this.bSnowRainToday = Number.parseFloat( response.list[ind1].snow[ "3h" ] )
               } else if ( response.list[ind1].rain !== undefined ) {
                this.isSnowRainToday = true;
                let tmpMM: string = response.list[ind1].rain[ "3h" ];
                this.snowRainToday = 'raining' + tmpMM + ' lit/m2';
                this.bSnowRainToday = Number.parseFloat( response.list[ind1].rain[ "3h" ] )
                console.log( Number.parseFloat( tmpMM ) );
               } else {
                this.isSnowRainToday = false;
              }

              this.mestoTomorrowMin = new Mesto('test@emg.si', 'Maribor', '20°C','24', 'cloudy', 20, 'cloudy', 2.5, '10000');
              this.mestoTomorrow = new Mesto('test@emg.si', 'Maribor', '20°C','24', 'cloudy', 20, 'cloudy', 2.5, '10000');
              this.mestoTomorrowMin.name = response.city.name;
              this.mestoTomorrowMin.temp = (response.list[ind2min].main.temp - 273.16).toFixed(1); // Name ()
              this.mestoTomorrowMin.humidity = +response.list[ind2min].main.humidity;
              this.mestoTomorrow.name = response.city.name;
              this.mestoTomorrow.temp = (response.list[ind2].main.temp - 273.16).toFixed(1); // Name ()
              this.mestoTomorrow.feels_like = (response.list[ind2].main.feels_like - 273.16).toFixed(1);
              this.mestoTomorrow.weather = response.list[ind2].weather[0].main;
              this.mestoTomorrow.humidity = +response.list[ind2].main.humidity;
              this.mestoTomorrow.description = response.list[ind2].weather[0].description;
              this.mestoTomorrow.windspeed = (response.list[ind2].wind.speed).toFixed(1);
              this.mestoTomorrow.visibility = response.list[ind2].visibility;
              this.dateTomorow = new Date( response.list[ind2].dt_txt );
              if ( response.list[ind2].snow !== undefined) {
                this.isSnowRainTomorow = true;
                let tmpMM: string = response.list[ind2].snow[ "3h" ];
                this.snowRainTomorow = 'snowing' + tmpMM + ' lit/m2';
                this.bSnowRainTomorow = Number.parseFloat( response.list[ind2].snow[ "3h" ] )
               } else if ( response.list[ind2].rain !== undefined ) {
                this.isSnowRainTomorow = true;
                let tmpMM: string = response.list[ind2].rain[ "3h" ];
                this.snowRainTomorow = 'raining' + tmpMM + ' lit/m2';
                this.bSnowRainTomorow = Number.parseFloat( response.list[ind2].rain[ "3h" ] )

                console.log( Number.parseFloat( tmpMM ) );
               } else {
                this.isSnowRainTomorow = false;
              }

              this.mestoAfterTomorrowMin = new Mesto('test@emg.si', 'Maribor', '20°C','24', 'cloudy', 20, 'cloudy', 2.5, '10000');
              this.mestoAfterTomorrow = new Mesto('test@emg.si', 'Maribor', '20°C','24', 'cloudy', 20, 'cloudy', 2.5, '10000');
              this.mestoAfterTomorrowMin.name = response.city.name;
              this.mestoAfterTomorrowMin.temp = (response.list[ind3min].main.temp - 273.16).toFixed(1); // Name ()
              this.mestoAfterTomorrowMin.humidity = +response.list[ind3min].main.humidity;
              this.mestoAfterTomorrow.name = response.city.name;
              this.mestoAfterTomorrow.temp = (response.list[ind3].main.temp - 273.16).toFixed(1); // Name ()
              this.mestoAfterTomorrow.feels_like = (response.list[ind3].main.feels_like - 273.16).toFixed(1);
              this.mestoAfterTomorrow.weather = response.list[ind3].weather[0].main;
              this.mestoAfterTomorrow.humidity = +response.list[ind3].main.humidity;
              this.mestoAfterTomorrow.description = response.list[ind3].weather[0].description;
              this.mestoAfterTomorrow.windspeed = (response.list[ind3].wind.speed).toFixed(1);
              this.mestoAfterTomorrow.visibility = response.list[ind3].visibility;
              this.dateAfterTomorrow = new Date( response.list[ind3].dt_txt );
              if ( response.list[ind3].snow !== undefined) {
                this.isSnowRainAfterTomorow = true;
                let tmpMM: string = response.list[ind3].snow[ "3h" ];
                this.snowRainAfterTomorow = 'snowing' + tmpMM + ' lit/m2';
                this.bSnowRainAfterTomorow = Number.parseFloat( response.list[ind3].snow[ "3h" ] )
              } else if ( response.list[ind3].rain !== undefined ) {
                this.isSnowRainAfterTomorow = true;
                let tmpMM: string = response.list[ind3].rain[ "3h" ];
                this.snowRainAfterTomorow = 'raining' + tmpMM + ' lit/m2';
                this.bSnowRainAfterTomorow = Number.parseFloat( tmpMM )

                console.log( Number.parseFloat( response.list[ind3].rain[ "3h" ] ) );
              } else {
                this.isSnowRainAfterTomorow = false;
              }


              this.mestoThreeDaysMin = new Mesto('test@emg.si', 'Maribor', '20°C','24', 'cloudy', 20, 'cloudy', 2.5, '10000');
              this.mestoThreeDays = new Mesto('test@emg.si', 'Maribor', '20°C','24', 'cloudy', 20, 'cloudy', 2.5, '10000');
              this.mestoThreeDaysMin.name = response.city.name;
              this.mestoThreeDaysMin.temp = (response.list[ind4min].main.temp - 273.16).toFixed(1); // Name ()
              this.mestoThreeDaysMin.humidity = +response.list[ind4min].main.humidity;
              this.mestoThreeDays.name = response.city.name;
              this.mestoThreeDays.temp = (response.list[ind4].main.temp - 273.16).toFixed(1); // Name ()
              this.mestoThreeDays.feels_like = (response.list[ind4].main.feels_like - 273.16).toFixed(1);
              this.mestoThreeDays.weather = response.list[ind4].weather[0].main;
              this.mestoThreeDays.humidity = +response.list[ind4].main.humidity;
              this.mestoThreeDays.description = response.list[ind4].weather[0].description;
              this.mestoThreeDays.windspeed = (response.list[ind4].wind.speed).toFixed(1);
              this.mestoThreeDays.visibility = response.list[ind4].visibility;
              this.dateThreeDays = new Date( response.list[ind4].dt_txt );
              if ( response.list[ind4].snow !== undefined) {
                this.isSnowRainThreeDays = true;
                let tmpMM: string = (response.list[ind4].snow[ "3h" ] !== undefined) ? response.list[ind4].snow[ "3h" ]  : '0.0';
                this.snowRainThreeDays = 'snowing' + tmpMM + ' lit/m2';
                this.bSnowRainThreeDays = Number.parseFloat( response.list[ind4].snow[ "3h" ] )
               } else if ( response.list[ind4].rain !== undefined ) {
                this.isSnowRainThreeDays = true;
                let tmpMM: string = (response.list[ind4].rain[ "3h" ] !== undefined) ? response.list[ind4].rain[ "3h" ]  : '0.0';
                this.snowRainThreeDays = 'raining' + tmpMM + ' lit/m2';
                this.bSnowRainThreeDays = Number.parseFloat( response.list[ind4].rain[ "3h" ] )

              } else {
                this.isSnowRainThreeDays = false;
              }


              this.mestoFourDaysMin = new Mesto('test@emg.si', 'Maribor', '20°C','24', 'cloudy', 20, 'cloudy', 2.5, '10000');
              this.mestoFourDays = new Mesto('test@emg.si', 'Maribor', '20°C','24', 'cloudy', 20, 'cloudy', 2.5, '10000');
              this.mestoFourDaysMin.name = response.city.name;
              this.mestoFourDaysMin.temp = (response.list[ind5min].main.temp - 273.16).toFixed(1); // Name ()
              this.mestoFourDaysMin.humidity = +response.list[ind5min].main.humidity;
              this.mestoFourDays.name = response.city.name;
              this.mestoFourDays.temp = (response.list[ind5].main.temp - 273.16).toFixed(1); // Name ()
              this.mestoFourDays.feels_like = (response.list[ind5].main.feels_like - 273.16).toFixed(1);
              this.mestoFourDays.weather = response.list[ind5].weather[0].main;
              this.mestoFourDays.humidity = +response.list[ind5].main.humidity;
              this.mestoFourDays.description = response.list[ind5].weather[0].description;
              this.mestoFourDays.windspeed = (response.list[ind5].wind.speed).toFixed(1);
              this.mestoFourDays.visibility = response.list[ind5].visibility;
              this.dateFourDays = new Date( response.list[ind5].dt_txt );
              if ( response.list[ind5].snow !== undefined) {
                this.isSnowRainFourDays = true;
                let tmpMM: string = (response.list[ind5].snow.h !== undefined) ? response.list[ind5].snow.h  : '0.0';
                this.snowRainFourDays = 'snowing' + tmpMM + ' lit/m2';
                this.bSnowRainFourDays = Number.parseFloat( response.list[ind5].snow[ "3h" ] )
              } else if ( response.list[ind5].rain !== undefined ) {
                this.isSnowRainFourDays = true;
                let tmpMM: string = (response.list[ind5].rain.h !== undefined) ? response.list[ind5].rain.h  : '0.0';
                this.snowRainFourDays = 'raining' + tmpMM + ' lit/m2';
                this.bSnowRainFourDays = Number.parseFloat( response.list[ind5].rain[ "3h" ] )
               } else {
                this.isSnowRainFourDays = false;
              }

              this.error = false;
              this.errorStr = (this.getWeatherForecastForCity(this.mesto.name)).cityName;
              this.date = new Date();
              this.isSubmited = true;

              this.update(new Event(' '));

              this.pushNewWeatherForecast();

              return response;
          },
          (error2: any) => {
            this.error = true;
            if (!error2 || !error2.error || !error2.error.message) {
              this.errorStr = 'unknown error';
            } else {
              this.errorStr = error2.error.message;
            }
              console.log( "error" );
            console.log(error2);
          }

      ) )

      .subscribe(
        // Se narocimo, da bomo poslusali kdaj prejmemo objekt.
        // Subscribe metoda je v opuščanju in edina dela in nima new Razredov
        (response) => {
              // dodali metodo za zapiši recepte
              let mesto = new Mesto('test@emg.si', 'name', '', '',
                'cloudy',20, 'no', 20, '');

              console.log(' response subscription je ');
              console.log( response );


              // we need query
              this.responseQuery = response;


              // obvestimo da je sprememba v osnovnem getNapoved(name) servicu
              let ind1 = 0;
              let ind1min = 0;
              let ind2 = 8;
              let ind2min = 8;
              let ind3 = 14;
              let ind3min = 14;
              let ind4 = 22;
              let ind4min = 22;
              let ind5 = 30;
              let ind5min = 30;
              for (let i = 0; i < 40; i++) {
                if ((response.list[i].dt_txt).indexOf('3:00:00') > 0 && i < 8) {
                  ind1min = i;

                  continue;
                } else if ((response.list[i].dt_txt).indexOf('12:00:00') > 0 && i < 8) {
                  this.izracunajDanasnjiDan( new Date() );
                  ind1 = i;

                  continue;
                } else if ((response.list[i].dt_txt).indexOf('3:00:00') > 0 && i < 16 && i >= 8) {
                  ind2min = i;

                  continue;
                } else if ((response.list[i].dt_txt).indexOf('12:00:00') > 0 && i < 16 && i >= 8) {
                  ind2 = i;

                  continue;
                } else if ((response.list[i].dt_txt).indexOf('3:00:00') > 0 && i < 24 && i >= 16) {
                  ind3min = i;

                  continue;
                } else if ((response.list[i].dt_txt).indexOf('12:00:00') > 0 && i < 24 && i >= 16) {
                  ind3 = i;

                  continue;
                } else if ((response.list[i].dt_txt).indexOf('3:00:00') > 0 && i < 32 && i >= 24) {
                  ind4min = i;

                  continue;
                } else if ((response.list[i].dt_txt).indexOf('12:00:00') > 0 && i < 32 && i >= 24) {
                  ind4 = i;

                  continue;
                } else if ((response.list[i].dt_txt).indexOf('3:00:00') > 0 && i < 40 && i >= 32) {
                  ind5min = i;

                  continue;
                } else if ((response.list[i].dt_txt).indexOf('12:00:00') > 0 && i < 40 && i >= 32) {
                  ind5 = i;

                  break;
                }
              }

              this.mestoTodayMin.name = response.city.name;
              this.mestoTodayMin.temp = (response.list[ind1min].main.temp - 273.16).toFixed(1); // Name ()
              this.mestoTodayMin.humidity = +response.list[ind1min].main.humidity;
              this.mestoToday.name = response.city.name;
              this.mestoToday.temp = (response.list[ind1].main.temp - 273.16).toFixed(1); // Name ()
              this.mestoToday.feels_like = (response.list[ind1].main.feels_like - 273.16).toFixed(1);
              this.mestoToday.weather = response.list[ind1].weather[0].main;
              this.mestoToday.humidity = +response.list[ind1].main.humidity;
              this.mestoToday.description = response.list[ind1].weather[0].description;
              this.mestoToday.windspeed = (response.list[ind1].wind.speed).toFixed(1);
              this.mestoToday.visibility = response.list[ind1].visibility;
              this.dateToday = new Date( response.list[ind1].dt_txt );
              if ( response.list[ind1].snow !== undefined) {
                this.isSnowRainToday = true;
                let tmpMM: string = response.list[ind1].snow[ "3h" ];
                this.snowRainToday = 'snowing' + tmpMM + ' lit/m2';
                this.bSnowRainToday = Number.parseFloat( response.list[ind1].snow[ "3h" ] )
               } else if ( response.list[ind1].rain !== undefined ) {
                this.isSnowRainToday = true;
                let tmpMM: string = response.list[ind1].rain[ "3h" ];
                this.snowRainToday = 'raining' + tmpMM + ' lit/m2';
                this.bSnowRainToday = Number.parseFloat( response.list[ind1].rain[ "3h" ] )
                console.log( Number.parseFloat( tmpMM ) );
               } else {
                this.isSnowRainToday = false;
              }

              this.mestoTomorrowMin.name = response.city.name;
              this.mestoTomorrowMin.temp = (response.list[ind2min].main.temp - 273.16).toFixed(1); // Name ()
              this.mestoTomorrowMin.humidity = +response.list[ind2min].main.humidity;
              this.mestoTomorrow.name = response.city.name;
              this.mestoTomorrow.temp = (response.list[ind2].main.temp - 273.16).toFixed(1); // Name ()
              this.mestoTomorrow.feels_like = (response.list[ind2].main.feels_like - 273.16).toFixed(1);
              this.mestoTomorrow.weather = response.list[ind2].weather[0].main;
              this.mestoTomorrow.humidity = +response.list[ind2].main.humidity;
              this.mestoTomorrow.description = response.list[ind2].weather[0].description;
              this.mestoTomorrow.windspeed = (response.list[ind2].wind.speed).toFixed(1);
              this.mestoTomorrow.visibility = response.list[ind2].visibility;
              this.dateTomorow = new Date( response.list[ind2].dt_txt );
              if ( response.list[ind2].snow !== undefined) {
                this.isSnowRainTomorow = true;
                let tmpMM: string = response.list[ind2].snow[ "3h" ];
                this.snowRainTomorow = 'snowing' + tmpMM + ' lit/m2';
                this.bSnowRainTomorow = Number.parseFloat( response.list[ind2].snow[ "3h" ] )
               } else if ( response.list[ind2].rain !== undefined ) {
                this.isSnowRainTomorow = true;
                let tmpMM: string = response.list[ind2].rain[ "3h" ];
                this.snowRainTomorow = 'raining' + tmpMM + ' lit/m2';
                this.bSnowRainTomorow = Number.parseFloat( response.list[ind2].rain[ "3h" ] )

                console.log( Number.parseFloat( tmpMM ) );
               } else {
                this.isSnowRainTomorow = false;
              }

              this.mestoAfterTomorrowMin.name = response.city.name;
              this.mestoAfterTomorrowMin.temp = (response.list[ind3min].main.temp - 273.16).toFixed(1); // Name ()
              this.mestoAfterTomorrowMin.humidity = +response.list[ind3min].main.humidity;
              this.mestoAfterTomorrow.name = response.city.name;
              this.mestoAfterTomorrow.temp = (response.list[ind3].main.temp - 273.16).toFixed(1); // Name ()
              this.mestoAfterTomorrow.feels_like = (response.list[ind3].main.feels_like - 273.16).toFixed(1);
              this.mestoAfterTomorrow.weather = response.list[ind3].weather[0].main;
              this.mestoAfterTomorrow.humidity = +response.list[ind3].main.humidity;
              this.mestoAfterTomorrow.description = response.list[ind3].weather[0].description;
              this.mestoAfterTomorrow.windspeed = (response.list[ind3].wind.speed).toFixed(1);
              this.mestoAfterTomorrow.visibility = response.list[ind3].visibility;
              this.dateAfterTomorrow = new Date( response.list[ind3].dt_txt );
              if ( response.list[ind3].snow !== undefined) {
                this.isSnowRainAfterTomorow = true;
                let tmpMM: string = response.list[ind3].snow[ "3h" ];
                this.snowRainAfterTomorow = 'snowing' + tmpMM + ' lit/m2';
                this.bSnowRainAfterTomorow = Number.parseFloat( response.list[ind3].snow[ "3h" ] )
              } else if ( response.list[ind3].rain !== undefined ) {
                this.isSnowRainAfterTomorow = true;
                let tmpMM: string = response.list[ind3].rain[ "3h" ];
                this.snowRainAfterTomorow = 'raining' + tmpMM + ' lit/m2';
                this.bSnowRainAfterTomorow = Number.parseFloat( tmpMM )

                console.log( Number.parseFloat( response.list[ind3].rain[ "3h" ] ) );
              } else {
                this.isSnowRainAfterTomorow = false;
              }


              this.mestoThreeDaysMin.name = response.city.name;
              this.mestoThreeDaysMin.temp = (response.list[ind4min].main.temp - 273.16).toFixed(1); // Name ()
              this.mestoThreeDaysMin.humidity = +response.list[ind4min].main.humidity;
              this.mestoThreeDays.name = response.city.name;
              this.mestoThreeDays.temp = (response.list[ind4].main.temp - 273.16).toFixed(1); // Name ()
              this.mestoThreeDays.feels_like = (response.list[ind4].main.feels_like - 273.16).toFixed(1);
              this.mestoThreeDays.weather = response.list[ind4].weather[0].main;
              this.mestoThreeDays.humidity = +response.list[ind4].main.humidity;
              this.mestoThreeDays.description = response.list[ind4].weather[0].description;
              this.mestoThreeDays.windspeed = (response.list[ind4].wind.speed).toFixed(1);
              this.mestoThreeDays.visibility = response.list[ind4].visibility;
              this.dateThreeDays = new Date( response.list[ind4].dt_txt );
              if ( response.list[ind4].snow !== undefined) {
                this.isSnowRainThreeDays = true;
                let tmpMM: string = (response.list[ind4].snow[ "3h" ] !== undefined) ? response.list[ind4].snow[ "3h" ]  : '0.0';
                this.snowRainThreeDays = 'snowing' + tmpMM + ' lit/m2';
                this.bSnowRainThreeDays = Number.parseFloat( response.list[ind4].snow[ "3h" ] )
               } else if ( response.list[ind4].rain !== undefined ) {
                this.isSnowRainThreeDays = true;
                let tmpMM: string = (response.list[ind4].rain[ "3h" ] !== undefined) ? response.list[ind4].rain[ "3h" ]  : '0.0';
                this.snowRainThreeDays = 'raining' + tmpMM + ' lit/m2';
                this.bSnowRainThreeDays = Number.parseFloat( response.list[ind4].rain[ "3h" ] )

              } else {
                this.isSnowRainThreeDays = false;
              }


              this.mestoFourDaysMin.name = response.city.name;
              this.mestoFourDaysMin.temp = (response.list[ind5min].main.temp - 273.16).toFixed(1); // Name ()
              this.mestoFourDaysMin.humidity = +response.list[ind5min].main.humidity;
              this.mestoFourDays.name = response.city.name;
              this.mestoFourDays.temp = (response.list[ind5].main.temp - 273.16).toFixed(1); // Name ()
              this.mestoFourDays.feels_like = (response.list[ind5].main.feels_like - 273.16).toFixed(1);
              this.mestoFourDays.weather = response.list[ind5].weather[0].main;
              this.mestoFourDays.humidity = +response.list[ind5].main.humidity;
              this.mestoFourDays.description = response.list[ind5].weather[0].description;
              this.mestoFourDays.windspeed = (response.list[ind5].wind.speed).toFixed(1);
              this.mestoFourDays.visibility = response.list[ind5].visibility;
              this.dateFourDays = new Date( response.list[ind5].dt_txt );
              if ( response.list[ind5].snow !== undefined) {
                this.isSnowRainFourDays = true;
                let tmpMM: string = (response.list[ind5].snow.h !== undefined) ? response.list[ind5].snow.h  : '0.0';
                this.snowRainFourDays = 'snowing' + tmpMM + ' lit/m2';
                this.bSnowRainFourDays = Number.parseFloat( response.list[ind5].snow[ "3h" ] )
              } else if ( response.list[ind5].rain !== undefined ) {
                this.isSnowRainFourDays = true;
                let tmpMM: string = (response.list[ind5].rain.h !== undefined) ? response.list[ind5].rain.h  : '0.0';
                this.snowRainFourDays = 'raining' + tmpMM + ' lit/m2';
                this.bSnowRainFourDays = Number.parseFloat( response.list[ind5].rain[ "3h" ] )
               } else {
                this.isSnowRainFourDays = false;
              }



              this.error = false;
              this.errorStr = (this.getWeatherForecastForCity(mesto.name)).cityName;
              this.date = new Date();

//              this.update(new Event(' '));
              this.thisSubj.next(true);

              clearInterval(this.interval);
              this.isSubmited = true;
//              this.pushNewWeatherForecast();

              return true;
        },
        (error) => {
          console.log(error);
          this.error = true;
          if (!error || !error.error || !error.error.message) {
            this.errorStr = 'unknown error';
          } else {
            this.errorStr = error.error.message;
          }
          console.log( "error" );


          clearInterval(this.interval);

        }
        );
      }, 3000);

  }

  // Porine novo vremensko napoved v array
  pushNewWeatherForecast() {
    let weather = new WeatherForecast2();
    weather.mesto = this.mestoToday;
    weather.error = this.error;
    weather.errorStr = this.errorStr;
    weather.isSubmited = this.isSubmited;
    weather.mestoToday = this.mestoToday;
    weather.mestoTomorrow = this.mestoTomorrow;
    weather.mestoAfterTomorrow = this.mestoAfterTomorrow;
    weather.mestoThreeDays = this.mestoThreeDays;
    weather.mestoFourDays = this.mestoFourDays;
    weather.mestoTodayMin = this.mestoTodayMin;
    weather.mestoTomorrowMin = this.mestoTomorrowMin;
    weather.mestoAfterTomorrowMin = this.mestoAfterTomorrowMin;
    weather.mestoThreeDaysMin = this.mestoThreeDaysMin;
    weather.mestoFourDaysMin = this.mestoFourDaysMin;
    weather.dateToday = this.dateToday;
    weather.dateTomorow = this.dateTomorow;
    weather.dateAfterTomorrow = this.dateAfterTomorrow; 
    weather.dateThreeDays = this.dateThreeDays;
    weather.dateFourDays = this.dateFourDays;
    weather.isSnowRainToday = this.isSnowRainToday;
    weather.isSnowRainTomorow = this.isSnowRainTomorow;
    weather.isSnowRainAfterTomorow = this.isSnowRainAfterTomorow;
    weather.isSnowRainThreeDays = this.isSnowRainThreeDays;
    weather.isSnowRainFourDays = this.isSnowRainFourDays;
    weather.snowRainToday = this.snowRainToday;
    weather.snowRainTomorow = this.snowRainTomorow;
    weather.snowRainAfterTomorow = this.snowRainAfterTomorow;
    weather.snowRainThreeDays = this.snowRainThreeDays;
    weather.snowRainFourDays = this.snowRainFourDays;
    weather.bSnowRainToday = this.bSnowRainToday;
    weather.bSnowRainTomorow = this.bSnowRainTomorow;
    weather.bSnowRainAfterTomorow = this.bSnowRainAfterTomorow;
    weather.bSnowRainThreeDays = this.bSnowRainThreeDays;
    weather.bSnowRainFourDays = this.bSnowRainFourDays;
    weather.minDan = this.minDan;
    weather.maxDan = this.maxDan;
    weather.danasnjaDolzinaDneva = this.danasnjaDolzinaDneva;
  
    weather.responseQuery = this.responseQuery; 
    weather.data = this.data;
    weather.options = this.options;
    weather.clickToggle = false;

    this.weatherForecast2.push(weather);
    console.log('Forecasts');
    console.log(this.weatherForecast2);
  }



  // izracuna danasnji dan
  // danasnji dan je ali pristevek k minimalnemu
  // ali odstevek od maksimalnega
  // potrebujemo tudi datum cetrte nedelje v marcu in datum cetrte oktoberske nedelje
  novoUrVzhod: number = 12.0;
  novoUrZahod: number = 12.0;
  pristejEnoUro: number = -1.0;
  danasnjiDatum: Date = new Date();

  izracunajDanasnjiDan(datumDanes: Date) {
    console.log(
      'toString ' + datumDanes.toDateString() +
      ' ,številka dne ' + datumDanes.getDate() +
      ' ,weekday ' + datumDanes.getDay() +
      ' ,month ' + datumDanes.getMonth()
    );
    this.danasnjiDatum = new Date();
    // hipoteza: cel datum
    // pomeni dni minus 1
    // pomeni dan v tednu če je 0 nedelja
    // pomeni mesec minus ena


    let tmpCetrtaMarceva: Date = new Date();
    tmpCetrtaMarceva.setMonth(2);

    let teden = 0;
    tmpCetrtaMarceva.setDate(  tmpCetrtaMarceva.getDate() - tmpCetrtaMarceva.getDay() );
    teden = +(tmpCetrtaMarceva.getDate() / 7).toFixed(0); //+ ((tmpCetrtaMarceva.getDate() % 7) > 0 ? 1 : 0);
//    console.log('kateri teden marca ' + teden);
    tmpCetrtaMarceva.setDate( tmpCetrtaMarceva.getDate() + ((4 - teden) * 7));
    console.log('cetrta nedelja marca ' + tmpCetrtaMarceva.toDateString() );
    // tmp cetrta marceva je zdaj datum premika ure

    if ((datumDanes.getMonth() < tmpCetrtaMarceva.getMonth())
      || (datumDanes.getMonth() === tmpCetrtaMarceva.getMonth()
      && datumDanes.getDate() < tmpCetrtaMarceva.getDate() )) {
      this.pristejEnoUro = 0.0;
    }

//    console.log('pristej Uro ' + this.pristejEnoUro + ', ms ' + datumDanes.getMilliseconds() );

    let tmpCetrtaOktoberska: Date = new Date();
    tmpCetrtaOktoberska.setMonth(9);
    let tedenZ = 0;
    tmpCetrtaOktoberska.setDate(  tmpCetrtaOktoberska.getDate() - tmpCetrtaOktoberska.getDay() );
    tedenZ = +(tmpCetrtaOktoberska.getDate() / 7).toFixed(0)+ ((tmpCetrtaOktoberska.getDate() % 7) > 0 ? 1 : 0);
//    console.log('teden oktobra ' + tedenZ);
    for (let i = 31; i > 0; i--) {
      tmpCetrtaOktoberska.setDate(i);
      if (tmpCetrtaOktoberska.getDay() === 0) {
        break;
      }
    }
//    tmpCetrtaOktoberska.setDate( tmpCetrtaOktoberska.getDate() + ((4 - tedenZ) * 7));
    console.log('cetrta oktoberska nedelja ' + tmpCetrtaOktoberska.toDateString());
    // tmp cetrta marceva je zdaj datum premika ure

    if ((datumDanes.getMonth() > 2
      && datumDanes.getMonth() < 9)
      || (datumDanes.getMonth() === 2
        && datumDanes.getDate() >= tmpCetrtaMarceva.getDate())
      || (datumDanes.getMonth() === 9
        && datumDanes.getDate() < tmpCetrtaOktoberska.getDate())
      )
    {
      this.pristejEnoUro = 1.0;
//      console.log('jesen, pristej: ' + this.pristejEnoUro);
    }

    if ((datumDanes.getMonth() > 9)
      || (datumDanes.getMonth() === 9
        && datumDanes.getDate() >= tmpCetrtaOktoberska.getDate())
    ) {
      this.pristejEnoUro = 0.0;
    }

//    console.log('kaj je pristej eno uro: ' + this.pristejEnoUro);

    // imamo 2 datuma ali pomladna ekstrema, narascajoca
    let rastociEkstremMin: Date = new Date();
    let rastociEkstremMax: Date = new Date();

    // ali jesenska ekstrema, padajoca
    let padajociEkstremMax: Date = new Date();
    let padajociEkstremMin: Date = new Date();
    let jePadajoc = false;
    let jeZadnjiTeden = false;
    let steviloDniVCasu: number = -1;

    if ((datumDanes.getMonth() >= 0 && datumDanes.getMonth() < 5)
      || (datumDanes.getMonth() === 11 && datumDanes.getDate() >= 21)
      || (datumDanes.getMonth() === 5 && datumDanes.getDate() < 21)
    )
    {
        // izjema, rastoci cas do 21. junij
      if (datumDanes.getMonth() === 11 && datumDanes.getDate() >= 21) {
        // rastoca zima
        rastociEkstremMin = new Date();
        rastociEkstremMin.setDate(21);
        jePadajoc = false;
        jeZadnjiTeden = true;
        // in drugi mejniki pol-letja
        rastociEkstremMax = new Date();
        rastociEkstremMax.setFullYear(rastociEkstremMax.getFullYear() + 1);
        rastociEkstremMax.setMonth(5);
        rastociEkstremMax.setDate(21);
        // predhodno pol-letje je bilo
        padajociEkstremMin = rastociEkstremMin;
        padajociEkstremMax = new Date();
        padajociEkstremMax.setMonth(5);
        padajociEkstremMax.setDate(21);

        // stevilo dni
        steviloDniVCasu = datumDanes.getDate() - 21; // x - rastociEkstremMin.getDate()
        console.log('se daljša, bozic bil ' + rastociEkstremMin.toDateString() );
        console.log('se daljša, maks ' + rastociEkstremMax.toDateString());
        console.log('preteklo krajsanje, vrh '+ padajociEkstremMax.toDateString());
        console.log('preteklo krajsanje, minimum '+ padajociEkstremMin.toDateString());
        console.log('stevilo dni je ' + steviloDniVCasu);
      }
      if ((datumDanes.getMonth() >= 0 && datumDanes.getMonth() < 5)
        || (datumDanes.getMonth() === 5 && datumDanes.getDate() < 21)
      )
      {
        padajociEkstremMax = new Date();
        padajociEkstremMax.setDate(21);
        padajociEkstremMax.setMonth(5);
        rastociEkstremMax = padajociEkstremMax;
        rastociEkstremMin = new Date();
        rastociEkstremMin.setFullYear( rastociEkstremMin.getFullYear() - 1  );
        rastociEkstremMin.setMonth(11);
        rastociEkstremMin.setDate(21);
        jePadajoc = false;
        jeZadnjiTeden = false;

        padajociEkstremMin = new Date();
        padajociEkstremMin.setMonth(11);
        padajociEkstremMin.setDate(21);

        steviloDniVCasu = 10;
        steviloDniVCasu += (datumDanes.getMonth() > 0) ? 31 : ( datumDanes.getMonth() === 0 ? (datumDanes.getDate() ) : 0);
        steviloDniVCasu += (datumDanes.getMonth() > 1) ? ((datumDanes.getFullYear() % 4 === 0) ? 29 : 28) : (datumDanes.getMonth() === 0 ? (datumDanes.getDate() + 1) : 0);
        steviloDniVCasu += (datumDanes.getMonth() > 2) ? 31 : (datumDanes.getMonth() === 2 ? (datumDanes.getDate() ) : 0);
        steviloDniVCasu += (datumDanes.getMonth() > 3) ? 30 : (datumDanes.getMonth() === 3 ? (datumDanes.getDate() ) : 0);
        steviloDniVCasu += (datumDanes.getMonth() > 4) ? 31 : (datumDanes.getMonth() === 4 ? (datumDanes.getDate() ) : 0);
        steviloDniVCasu += (datumDanes.getMonth() === 5) ? (datumDanes.getDate() ) : 0;

        console.log('se daljša, bozic bil ' + rastociEkstremMin.toDateString() );
        console.log('se daljša, maks ' + rastociEkstremMax.toDateString());
        console.log('preteklo krajsanje, vrh '+ padajociEkstremMax.toDateString());
        console.log('preteklo krajsanje, minimum '+ padajociEkstremMin.toDateString());
        console.log('stevilo dni je ' + steviloDniVCasu);

      }
      else {
        console.log('else rastoč, to se nebi smelo zgoditi, error, napaka');
      }
    }
    if ((datumDanes.getMonth() > 5 && datumDanes.getMonth() < 11)
      || (datumDanes.getMonth() === 11 && datumDanes.getDate() < 21)
      || (datumDanes.getMonth() === 5 && datumDanes.getDate() >= 21)
    )
    {
      padajociEkstremMax = new Date();
      padajociEkstremMax.setDate(21);
      padajociEkstremMax.setMonth(5);
      padajociEkstremMin = new Date();
      padajociEkstremMin.setMonth(11);
      padajociEkstremMin.setDate(21);
      jePadajoc = true;
      jeZadnjiTeden = false;
      rastociEkstremMax = padajociEkstremMax;

      rastociEkstremMin = new Date();
      rastociEkstremMin.setMonth(11);
      rastociEkstremMin.setDate(21);
      rastociEkstremMax = rastociEkstremMin;

      steviloDniVCasu = 0;
      steviloDniVCasu += (datumDanes.getMonth() === 5 && datumDanes.getDate() >= 21) ? (datumDanes.getDate()  - 21) : 11;
      steviloDniVCasu += (datumDanes.getMonth() >= 6) ? (datumDanes.getMonth() > 6 ? 31 : (datumDanes.getDate() )) : 0;
      steviloDniVCasu += (datumDanes.getMonth() >= 7) ? (datumDanes.getMonth() > 7 ? 31 : (datumDanes.getDate() )) : 0;
      steviloDniVCasu += (datumDanes.getMonth() >= 8) ? (datumDanes.getMonth() > 8 ? 30 : (datumDanes.getDate() )) : 0;
      steviloDniVCasu += (datumDanes.getMonth() >= 9) ? (datumDanes.getMonth() > 9 ? 31 : (datumDanes.getDate() )) : 0;;
      steviloDniVCasu += (datumDanes.getMonth() >= 10) ? (datumDanes.getMonth() > 10 ? 30 : (datumDanes.getDate() )) : 0;
      steviloDniVCasu += (datumDanes.getMonth() === 11 ) ? (datumDanes.getDate() ) : 0;

      console.log('se krajša min ' + rastociEkstremMin.toDateString() );
      console.log('se krajša max ' + rastociEkstremMax.toDateString());
      console.log('rastoce max '+ padajociEkstremMax.toDateString());
      console.log('novo rastoce min '+ padajociEkstremMin.toDateString());
      console.log('stevilo dni je ' + steviloDniVCasu);
    }


    // sedaj pa izracun stevilo dni v tem casu
    let procentPribitka: number = 0;
    let minUr: number = 8.15;
    let maxUr: number = 16.10;
    let razlikaUr: number = maxUr - minUr;
    let dolzinaDneva: number = 0;

    if (jePadajoc === false || jeZadnjiTeden === true)
    {
      procentPribitka = +(steviloDniVCasu / ((datumDanes.getFullYear() % 4 === 0) ? 183 : 182)).toFixed(2);
      razlikaUr = +(procentPribitka * (maxUr - minUr)).toFixed(2);
      dolzinaDneva = razlikaUr + minUr;
      this.novoUrVzhod = +(12.0 - (dolzinaDneva / 2) + this.pristejEnoUro).toFixed(2);
      this.novoUrZahod = +(12.0 + (dolzinaDneva / 2) + this.pristejEnoUro).toFixed(2);

//      console.log('procent priblizka '+ procentPribitka + ' razlikaUr na pol ' + razlikaUr + ', dolzina dneva ' + dolzinaDneva);
      if (this.pristejEnoUro > 0) {
        console.log('ste po poletnem zamaknjenem casu, ' + this.pristejEnoUro);
      } else {
        console.log('ste po soncnem zimskem casu ' + this.pristejEnoUro);
      }
      console.log('vzhod: ' + this.novoUrVzhod + ', zahod pa: ' + this.novoUrZahod);
    }
    if ( jePadajoc === true )
    {
      procentPribitka = +(steviloDniVCasu / 183).toFixed(2);
      razlikaUr = +(procentPribitka * (maxUr - minUr)).toFixed(2);
      dolzinaDneva = maxUr - razlikaUr;
      this.novoUrVzhod = +(12.0 - (dolzinaDneva / 2) + this.pristejEnoUro).toFixed(2);
      this.novoUrZahod = +(12.0 + (dolzinaDneva / 2) + this.pristejEnoUro).toFixed(2);

//      console.log('procent priblizka '+ procentPribitka + ' razlikaUr na pol ' + razlikaUr + ', dolzina dneva ' + dolzinaDneva);
      if (this.pristejEnoUro > 0) {
        console.log('ste po poletnem zamaknjenem casu, ' + this.pristejEnoUro);
      } else {
        console.log('ste po soncnem zimskem casu ' + this.pristejEnoUro);
      }
      console.log('vzhod: ' + this.novoUrVzhod + ', zahod pa: ' + this.novoUrZahod);
    }
    this.danasnjaDolzinaDneva = dolzinaDneva;

    
  }

  getForecastByGeolocation() {

    this.countWeatherTimes += 1;
    console.log('start' + ',,, counter ,,,' + this.countWeatherTimes);

    localStorage.setItem('weather-times', JSON.stringify(this.countWeatherTimes) );
    localStorage.setItem( 'weather-date', (new Date()).toLocaleDateString() );

    navigator.geolocation.getCurrentPosition((position) => {
      console.log('Latitude: ' + position.coords.latitude);
      console.log('Longitude: ' + position.coords.longitude);
      this.latitude = position.coords.latitude;
      this.longitude = position.coords.longitude;
    });
    /*
    if (this.countWeatherTimes * 40 > 948 || this.countWeatherTimes * 40 <= 0) {
      this.isSubmited = true;
      return;
    }
*/


      this.httpClient.get('https://api.openweathermap.org/data/2.5/forecast?lat='
      + this.latitude + '&lon=' + this.longitude + '&appid=fbd2befb1c3fa8f6f4343af5666d6150'
      )
      .pipe( map(
        // bindamo response v objekt
        // Put metoda ima New Razrede, da dobimo nove podatke iz pomnilnika
        (response: any) => {
            console.log(' forecast je ');
            console.log(response);

            // we need query
            this.responseQuery = response;

            // obvestimo da je sprememba v osnovnem getNapoved(name) servicu
            let ind1 = 0;
            let ind1min = 0;
            let ind2 = 8;
            let ind2min = 8;
            let ind3 = 14;
            let ind3min = 14;
            let ind4 = 22;
            let ind4min = 22;
            let ind5 = 30;
            let ind5min = 30;
            for (let i = 0; i < 40; i++) {
              if ((response.list[i].dt_txt).indexOf('3:00:00') > 0 && i < 8) {
                ind1min = i;

                continue;
              } else if ((response.list[i].dt_txt).indexOf('12:00:00') > 0 && i < 8) {
                this.izracunajDanasnjiDan( new Date() );
                ind1 = i;

                continue;
              } else if ((response.list[i].dt_txt).indexOf('3:00:00') > 0 && i < 16 && i >= 8) {
                ind2min = i;

                continue;
              } else if ((response.list[i].dt_txt).indexOf('12:00:00') > 0 && i < 16 && i >= 8) {
                ind2 = i;

                continue;
              } else if ((response.list[i].dt_txt).indexOf('3:00:00') > 0 && i < 24 && i >= 16) {
                ind3min = i;

                continue;
              } else if ((response.list[i].dt_txt).indexOf('12:00:00') > 0 && i < 24 && i >= 16) {
                ind3 = i;

                continue;
              } else if ((response.list[i].dt_txt).indexOf('3:00:00') > 0 && i < 32 && i >= 24) {
                ind4min = i;

                continue;
              } else if ((response.list[i].dt_txt).indexOf('12:00:00') > 0 && i < 32 && i >= 24) {
                ind4 = i;

                continue;
              } else if ((response.list[i].dt_txt).indexOf('3:00:00') > 0 && i < 40 && i >= 32) {
                ind5min = i;

                continue;
              } else if ((response.list[i].dt_txt).indexOf('12:00:00') > 0 && i < 40 && i >= 32) {
                ind5 = i;

                break;
              }
            }

            this.mestoTodayMin = new Mesto('test@emg.si', 'Maribor', '20°C','24', 'cloudy', 20, 'cloudy', 2.5, '10000');
            this.mestoToday = new Mesto('test@emg.si', 'Maribor', '20°C','24', 'cloudy', 20, 'cloudy', 2.5, '10000');
            this.mestoTodayMin.name = response.city.name;
            this.mestoTodayMin.temp = (response.list[ind1min].main.temp - 273.16).toFixed(1); // Name ()
            this.mestoTodayMin.humidity = +response.list[ind1min].main.humidity;
            this.mestoToday.name = response.city.name;
            this.mestoToday.temp = (response.list[ind1].main.temp - 273.16).toFixed(1); // Name ()
            this.mestoToday.feels_like = (response.list[ind1].main.feels_like - 273.16).toFixed(1);
            this.mestoToday.weather = response.list[ind1].weather[0].main;
            this.mestoToday.humidity = +response.list[ind1].main.humidity;
            this.mestoToday.description = response.list[ind1].weather[0].description;
            this.mestoToday.windspeed = (response.list[ind1].wind.speed).toFixed(1);
            this.mestoToday.visibility = response.list[ind1].visibility;
            this.dateToday = new Date( response.list[ind1].dt_txt );
            if ( response.list[ind1].snow !== undefined) {
              this.isSnowRainToday = true;
              let tmpMM: string = response.list[ind1].snow[ "3h" ];
              this.snowRainToday = 'snowing' + tmpMM + ' lit/m2';
              this.bSnowRainToday = Number.parseFloat( response.list[ind1].snow[ "3h" ] )
             } else if ( response.list[ind1].rain !== undefined ) {
              this.isSnowRainToday = true;
              let tmpMM: string = response.list[ind1].rain[ "3h" ];
              this.snowRainToday = 'raining' + tmpMM + ' lit/m2';
              this.bSnowRainToday = Number.parseFloat( response.list[ind1].rain[ "3h" ] )
              console.log( Number.parseFloat( tmpMM ) );
             } else {
              this.isSnowRainToday = false;
            }

            this.mestoTomorrowMin = new Mesto('test@emg.si', 'Maribor', '20°C','24', 'cloudy', 20, 'cloudy', 2.5, '10000');
            this.mestoTomorrow = new Mesto('test@emg.si', 'Maribor', '20°C','24', 'cloudy', 20, 'cloudy', 2.5, '10000');
            this.mestoTomorrowMin.name = response.city.name;
            this.mestoTomorrowMin.temp = (response.list[ind2min].main.temp - 273.16).toFixed(1); // Name ()
            this.mestoTomorrowMin.humidity = +response.list[ind2min].main.humidity;
            this.mestoTomorrow.name = response.city.name;
            this.mestoTomorrow.temp = (response.list[ind2].main.temp - 273.16).toFixed(1); // Name ()
            this.mestoTomorrow.feels_like = (response.list[ind2].main.feels_like - 273.16).toFixed(1);
            this.mestoTomorrow.weather = response.list[ind2].weather[0].main;
            this.mestoTomorrow.humidity = +response.list[ind2].main.humidity;
            this.mestoTomorrow.description = response.list[ind2].weather[0].description;
            this.mestoTomorrow.windspeed = (response.list[ind2].wind.speed).toFixed(1);
            this.mestoTomorrow.visibility = response.list[ind2].visibility;
            this.dateTomorow = new Date( response.list[ind2].dt_txt );
            if ( response.list[ind2].snow !== undefined) {
              this.isSnowRainTomorow = true;
              let tmpMM: string = response.list[ind2].snow[ "3h" ];
              this.snowRainTomorow = 'snowing' + tmpMM + ' lit/m2';
              this.bSnowRainTomorow = Number.parseFloat( response.list[ind2].snow[ "3h" ] )
             } else if ( response.list[ind2].rain !== undefined ) {
              this.isSnowRainTomorow = true;
              let tmpMM: string = response.list[ind2].rain[ "3h" ];
              this.snowRainTomorow = 'raining' + tmpMM + ' lit/m2';
              this.bSnowRainTomorow = Number.parseFloat( response.list[ind2].rain[ "3h" ] )

              console.log( Number.parseFloat( tmpMM ) );
             } else {
              this.isSnowRainTomorow = false;
            }

            this.mestoAfterTomorrowMin = new Mesto('test@emg.si', 'Maribor', '20°C','24', 'cloudy', 20, 'cloudy', 2.5, '10000');
            this.mestoAfterTomorrow = new Mesto('test@emg.si', 'Maribor', '20°C','24', 'cloudy', 20, 'cloudy', 2.5, '10000');
            this.mestoAfterTomorrowMin.name = response.city.name;
            this.mestoAfterTomorrowMin.temp = (response.list[ind3min].main.temp - 273.16).toFixed(1); // Name ()
            this.mestoAfterTomorrowMin.humidity = +response.list[ind3min].main.humidity;
            this.mestoAfterTomorrow.name = response.city.name;
            this.mestoAfterTomorrow.temp = (response.list[ind3].main.temp - 273.16).toFixed(1); // Name ()
            this.mestoAfterTomorrow.feels_like = (response.list[ind3].main.feels_like - 273.16).toFixed(1);
            this.mestoAfterTomorrow.weather = response.list[ind3].weather[0].main;
            this.mestoAfterTomorrow.humidity = +response.list[ind3].main.humidity;
            this.mestoAfterTomorrow.description = response.list[ind3].weather[0].description;
            this.mestoAfterTomorrow.windspeed = (response.list[ind3].wind.speed).toFixed(1);
            this.mestoAfterTomorrow.visibility = response.list[ind3].visibility;
            this.dateAfterTomorrow = new Date( response.list[ind3].dt_txt );
            if ( response.list[ind3].snow !== undefined) {
              this.isSnowRainAfterTomorow = true;
              let tmpMM: string = response.list[ind3].snow[ "3h" ];
              this.snowRainAfterTomorow = 'snowing' + tmpMM + ' lit/m2';
              this.bSnowRainAfterTomorow = Number.parseFloat( response.list[ind3].snow[ "3h" ] )
            } else if ( response.list[ind3].rain !== undefined ) {
              this.isSnowRainAfterTomorow = true;
              let tmpMM: string = response.list[ind3].rain[ "3h" ];
              this.snowRainAfterTomorow = 'raining' + tmpMM + ' lit/m2';
              this.bSnowRainAfterTomorow = Number.parseFloat( tmpMM )

              console.log( Number.parseFloat( response.list[ind3].rain[ "3h" ] ) );
            } else {
              this.isSnowRainAfterTomorow = false;
            }


            this.mestoThreeDaysMin = new Mesto('test@emg.si', 'Maribor', '20°C','24', 'cloudy', 20, 'cloudy', 2.5, '10000');
            this.mestoThreeDays = new Mesto('test@emg.si', 'Maribor', '20°C','24', 'cloudy', 20, 'cloudy', 2.5, '10000');
            this.mestoThreeDaysMin.name = response.city.name;
            this.mestoThreeDaysMin.temp = (response.list[ind4min].main.temp - 273.16).toFixed(1); // Name ()
            this.mestoThreeDaysMin.humidity = +response.list[ind4min].main.humidity;
            this.mestoThreeDays.name = response.city.name;
            this.mestoThreeDays.temp = (response.list[ind4].main.temp - 273.16).toFixed(1); // Name ()
            this.mestoThreeDays.feels_like = (response.list[ind4].main.feels_like - 273.16).toFixed(1);
            this.mestoThreeDays.weather = response.list[ind4].weather[0].main;
            this.mestoThreeDays.humidity = +response.list[ind4].main.humidity;
            this.mestoThreeDays.description = response.list[ind4].weather[0].description;
            this.mestoThreeDays.windspeed = (response.list[ind4].wind.speed).toFixed(1);
            this.mestoThreeDays.visibility = response.list[ind4].visibility;
            this.dateThreeDays = new Date( response.list[ind4].dt_txt );
            if ( response.list[ind4].snow !== undefined) {
              this.isSnowRainThreeDays = true;
              let tmpMM: string = (response.list[ind4].snow[ "3h" ] !== undefined) ? response.list[ind4].snow[ "3h" ]  : '0.0';
              this.snowRainThreeDays = 'snowing' + tmpMM + ' lit/m2';
              this.bSnowRainThreeDays = Number.parseFloat( response.list[ind4].snow[ "3h" ] )
             } else if ( response.list[ind4].rain !== undefined ) {
              this.isSnowRainThreeDays = true;
              let tmpMM: string = (response.list[ind4].rain[ "3h" ] !== undefined) ? response.list[ind4].rain[ "3h" ]  : '0.0';
              this.snowRainThreeDays = 'raining' + tmpMM + ' lit/m2';
              this.bSnowRainThreeDays = Number.parseFloat( response.list[ind4].rain[ "3h" ] )

            } else {
              this.isSnowRainThreeDays = false;
            }


            this.mestoFourDaysMin = new Mesto('test@emg.si', 'Maribor', '20°C','24', 'cloudy', 20, 'cloudy', 2.5, '10000');
            this.mestoFourDays = new Mesto('test@emg.si', 'Maribor', '20°C','24', 'cloudy', 20, 'cloudy', 2.5, '10000');
            this.mestoFourDaysMin.name = response.city.name;
            this.mestoFourDaysMin.temp = (response.list[ind5min].main.temp - 273.16).toFixed(1); // Name ()
            this.mestoFourDaysMin.humidity = +response.list[ind5min].main.humidity;
            this.mestoFourDays.name = response.city.name;
            this.mestoFourDays.temp = (response.list[ind5].main.temp - 273.16).toFixed(1); // Name ()
            this.mestoFourDays.feels_like = (response.list[ind5].main.feels_like - 273.16).toFixed(1);
            this.mestoFourDays.weather = response.list[ind5].weather[0].main;
            this.mestoFourDays.humidity = +response.list[ind5].main.humidity;
            this.mestoFourDays.description = response.list[ind5].weather[0].description;
            this.mestoFourDays.windspeed = (response.list[ind5].wind.speed).toFixed(1);
            this.mestoFourDays.visibility = response.list[ind5].visibility;
            this.dateFourDays = new Date( response.list[ind5].dt_txt );
            if ( response.list[ind5].snow !== undefined) {
              this.isSnowRainFourDays = true;
              let tmpMM: string = (response.list[ind5].snow.h !== undefined) ? response.list[ind5].snow.h  : '0.0';
              this.snowRainFourDays = 'snowing' + tmpMM + ' lit/m2';
              this.bSnowRainFourDays = Number.parseFloat( response.list[ind5].snow[ "3h" ] )
            } else if ( response.list[ind5].rain !== undefined ) {
              this.isSnowRainFourDays = true;
              let tmpMM: string = (response.list[ind5].rain.h !== undefined) ? response.list[ind5].rain.h  : '0.0';
              this.snowRainFourDays = 'raining' + tmpMM + ' lit/m2';
              this.bSnowRainFourDays = Number.parseFloat( response.list[ind5].rain[ "3h" ] )
             } else {
              this.isSnowRainFourDays = false;
            }

            this.error = false;
            this.errorStr = (this.getWeatherForecastForCity(this.mesto.name)).cityName;
            this.date = new Date();
            this.isSubmited = true;

            this.update(new Event(' '));

            this.pushNewWeatherForecast();

            return response;
        },
        (error2: any) => {
          this.error = true;
          if (!error2 || !error2.error || !error2.error.message) {
            this.errorStr = 'unknown error';
          } else {
            this.errorStr = error2.error.message;
          }
            console.log( "error" );
          console.log(error2);
        }

    ) )

    .subscribe(
      // Se narocimo, da bomo poslusali kdaj prejmemo objekt.
      // Subscribe metoda je v opuščanju in edina dela in nima new Razredov
      (response) => {
            // dodali metodo za zapiši recepte
            let mesto = new Mesto('test@emg.si', 'name', '', '',
              'cloudy',20, 'no', 20, '');

            console.log(' response subscription je ');
            console.log( response );


            // we need query
            this.responseQuery = response;


            // obvestimo da je sprememba v osnovnem getNapoved(name) servicu
            let ind1 = 0;
            let ind1min = 0;
            let ind2 = 8;
            let ind2min = 8;
            let ind3 = 14;
            let ind3min = 14;
            let ind4 = 22;
            let ind4min = 22;
            let ind5 = 30;
            let ind5min = 30;
            for (let i = 0; i < 40; i++) {
              if ((response.list[i].dt_txt).indexOf('3:00:00') > 0 && i < 8) {
                ind1min = i;

                continue;
              } else if ((response.list[i].dt_txt).indexOf('12:00:00') > 0 && i < 8) {
                this.izracunajDanasnjiDan( new Date() );
                ind1 = i;

                continue;
              } else if ((response.list[i].dt_txt).indexOf('3:00:00') > 0 && i < 16 && i >= 8) {
                ind2min = i;

                continue;
              } else if ((response.list[i].dt_txt).indexOf('12:00:00') > 0 && i < 16 && i >= 8) {
                ind2 = i;

                continue;
              } else if ((response.list[i].dt_txt).indexOf('3:00:00') > 0 && i < 24 && i >= 16) {
                ind3min = i;

                continue;
              } else if ((response.list[i].dt_txt).indexOf('12:00:00') > 0 && i < 24 && i >= 16) {
                ind3 = i;

                continue;
              } else if ((response.list[i].dt_txt).indexOf('3:00:00') > 0 && i < 32 && i >= 24) {
                ind4min = i;

                continue;
              } else if ((response.list[i].dt_txt).indexOf('12:00:00') > 0 && i < 32 && i >= 24) {
                ind4 = i;

                continue;
              } else if ((response.list[i].dt_txt).indexOf('3:00:00') > 0 && i < 40 && i >= 32) {
                ind5min = i;

                continue;
              } else if ((response.list[i].dt_txt).indexOf('12:00:00') > 0 && i < 40 && i >= 32) {
                ind5 = i;

                break;
              }
            }

            this.mestoTodayMin.name = response.city.name;
            this.mestoTodayMin.temp = (response.list[ind1min].main.temp - 273.16).toFixed(1); // Name ()
            this.mestoTodayMin.humidity = +response.list[ind1min].main.humidity;
            this.mestoToday.name = response.city.name;
            this.mestoToday.temp = (response.list[ind1].main.temp - 273.16).toFixed(1); // Name ()
            this.mestoToday.feels_like = (response.list[ind1].main.feels_like - 273.16).toFixed(1);
            this.mestoToday.weather = response.list[ind1].weather[0].main;
            this.mestoToday.humidity = +response.list[ind1].main.humidity;
            this.mestoToday.description = response.list[ind1].weather[0].description;
            this.mestoToday.windspeed = (response.list[ind1].wind.speed).toFixed(1);
            this.mestoToday.visibility = response.list[ind1].visibility;
            this.dateToday = new Date( response.list[ind1].dt_txt );
            if ( response.list[ind1].snow !== undefined) {
              this.isSnowRainToday = true;
              let tmpMM: string = response.list[ind1].snow[ "3h" ];
              this.snowRainToday = 'snowing' + tmpMM + ' lit/m2';
              this.bSnowRainToday = Number.parseFloat( response.list[ind1].snow[ "3h" ] )
             } else if ( response.list[ind1].rain !== undefined ) {
              this.isSnowRainToday = true;
              let tmpMM: string = response.list[ind1].rain[ "3h" ];
              this.snowRainToday = 'raining' + tmpMM + ' lit/m2';
              this.bSnowRainToday = Number.parseFloat( response.list[ind1].rain[ "3h" ] )
              console.log( Number.parseFloat( tmpMM ) );
             } else {
              this.isSnowRainToday = false;
            }

            this.mestoTomorrowMin.name = response.city.name;
            this.mestoTomorrowMin.temp = (response.list[ind2min].main.temp - 273.16).toFixed(1); // Name ()
            this.mestoTomorrowMin.humidity = +response.list[ind2min].main.humidity;
            this.mestoTomorrow.name = response.city.name;
            this.mestoTomorrow.temp = (response.list[ind2].main.temp - 273.16).toFixed(1); // Name ()
            this.mestoTomorrow.feels_like = (response.list[ind2].main.feels_like - 273.16).toFixed(1);
            this.mestoTomorrow.weather = response.list[ind2].weather[0].main;
            this.mestoTomorrow.humidity = +response.list[ind2].main.humidity;
            this.mestoTomorrow.description = response.list[ind2].weather[0].description;
            this.mestoTomorrow.windspeed = (response.list[ind2].wind.speed).toFixed(1);
            this.mestoTomorrow.visibility = response.list[ind2].visibility;
            this.dateTomorow = new Date( response.list[ind2].dt_txt );
            if ( response.list[ind2].snow !== undefined) {
              this.isSnowRainTomorow = true;
              let tmpMM: string = response.list[ind2].snow[ "3h" ];
              this.snowRainTomorow = 'snowing' + tmpMM + ' lit/m2';
              this.bSnowRainTomorow = Number.parseFloat( response.list[ind2].snow[ "3h" ] )
             } else if ( response.list[ind2].rain !== undefined ) {
              this.isSnowRainTomorow = true;
              let tmpMM: string = response.list[ind2].rain[ "3h" ];
              this.snowRainTomorow = 'raining' + tmpMM + ' lit/m2';
              this.bSnowRainTomorow = Number.parseFloat( response.list[ind2].rain[ "3h" ] )

              console.log( Number.parseFloat( tmpMM ) );
             } else {
              this.isSnowRainTomorow = false;
            }

            this.mestoAfterTomorrowMin.name = response.city.name;
            this.mestoAfterTomorrowMin.temp = (response.list[ind3min].main.temp - 273.16).toFixed(1); // Name ()
            this.mestoAfterTomorrowMin.humidity = +response.list[ind3min].main.humidity;
            this.mestoAfterTomorrow.name = response.city.name;
            this.mestoAfterTomorrow.temp = (response.list[ind3].main.temp - 273.16).toFixed(1); // Name ()
            this.mestoAfterTomorrow.feels_like = (response.list[ind3].main.feels_like - 273.16).toFixed(1);
            this.mestoAfterTomorrow.weather = response.list[ind3].weather[0].main;
            this.mestoAfterTomorrow.humidity = +response.list[ind3].main.humidity;
            this.mestoAfterTomorrow.description = response.list[ind3].weather[0].description;
            this.mestoAfterTomorrow.windspeed = (response.list[ind3].wind.speed).toFixed(1);
            this.mestoAfterTomorrow.visibility = response.list[ind3].visibility;
            this.dateAfterTomorrow = new Date( response.list[ind3].dt_txt );
            if ( response.list[ind3].snow !== undefined) {
              this.isSnowRainAfterTomorow = true;
              let tmpMM: string = response.list[ind3].snow[ "3h" ];
              this.snowRainAfterTomorow = 'snowing' + tmpMM + ' lit/m2';
              this.bSnowRainAfterTomorow = Number.parseFloat( response.list[ind3].snow[ "3h" ] )
            } else if ( response.list[ind3].rain !== undefined ) {
              this.isSnowRainAfterTomorow = true;
              let tmpMM: string = response.list[ind3].rain[ "3h" ];
              this.snowRainAfterTomorow = 'raining' + tmpMM + ' lit/m2';
              this.bSnowRainAfterTomorow = Number.parseFloat( tmpMM )

              console.log( Number.parseFloat( response.list[ind3].rain[ "3h" ] ) );
            } else {
              this.isSnowRainAfterTomorow = false;
            }


            this.mestoThreeDaysMin.name = response.city.name;
            this.mestoThreeDaysMin.temp = (response.list[ind4min].main.temp - 273.16).toFixed(1); // Name ()
            this.mestoThreeDaysMin.humidity = +response.list[ind4min].main.humidity;
            this.mestoThreeDays.name = response.city.name;
            this.mestoThreeDays.temp = (response.list[ind4].main.temp - 273.16).toFixed(1); // Name ()
            this.mestoThreeDays.feels_like = (response.list[ind4].main.feels_like - 273.16).toFixed(1);
            this.mestoThreeDays.weather = response.list[ind4].weather[0].main;
            this.mestoThreeDays.humidity = +response.list[ind4].main.humidity;
            this.mestoThreeDays.description = response.list[ind4].weather[0].description;
            this.mestoThreeDays.windspeed = (response.list[ind4].wind.speed).toFixed(1);
            this.mestoThreeDays.visibility = response.list[ind4].visibility;
            this.dateThreeDays = new Date( response.list[ind4].dt_txt );
            if ( response.list[ind4].snow !== undefined) {
              this.isSnowRainThreeDays = true;
              let tmpMM: string = (response.list[ind4].snow[ "3h" ] !== undefined) ? response.list[ind4].snow[ "3h" ]  : '0.0';
              this.snowRainThreeDays = 'snowing' + tmpMM + ' lit/m2';
              this.bSnowRainThreeDays = Number.parseFloat( response.list[ind4].snow[ "3h" ] )
             } else if ( response.list[ind4].rain !== undefined ) {
              this.isSnowRainThreeDays = true;
              let tmpMM: string = (response.list[ind4].rain[ "3h" ] !== undefined) ? response.list[ind4].rain[ "3h" ]  : '0.0';
              this.snowRainThreeDays = 'raining' + tmpMM + ' lit/m2';
              this.bSnowRainThreeDays = Number.parseFloat( response.list[ind4].rain[ "3h" ] )

            } else {
              this.isSnowRainThreeDays = false;
            }


            this.mestoFourDaysMin.name = response.city.name;
            this.mestoFourDaysMin.temp = (response.list[ind5min].main.temp - 273.16).toFixed(1); // Name ()
            this.mestoFourDaysMin.humidity = +response.list[ind5min].main.humidity;
            this.mestoFourDays.name = response.city.name;
            this.mestoFourDays.temp = (response.list[ind5].main.temp - 273.16).toFixed(1); // Name ()
            this.mestoFourDays.feels_like = (response.list[ind5].main.feels_like - 273.16).toFixed(1);
            this.mestoFourDays.weather = response.list[ind5].weather[0].main;
            this.mestoFourDays.humidity = +response.list[ind5].main.humidity;
            this.mestoFourDays.description = response.list[ind5].weather[0].description;
            this.mestoFourDays.windspeed = (response.list[ind5].wind.speed).toFixed(1);
            this.mestoFourDays.visibility = response.list[ind5].visibility;
            this.dateFourDays = new Date( response.list[ind5].dt_txt );
            if ( response.list[ind5].snow !== undefined) {
              this.isSnowRainFourDays = true;
              let tmpMM: string = (response.list[ind5].snow.h !== undefined) ? response.list[ind5].snow.h  : '0.0';
              this.snowRainFourDays = 'snowing' + tmpMM + ' lit/m2';
              this.bSnowRainFourDays = Number.parseFloat( response.list[ind5].snow[ "3h" ] )
            } else if ( response.list[ind5].rain !== undefined ) {
              this.isSnowRainFourDays = true;
              let tmpMM: string = (response.list[ind5].rain.h !== undefined) ? response.list[ind5].rain.h  : '0.0';
              this.snowRainFourDays = 'raining' + tmpMM + ' lit/m2';
              this.bSnowRainFourDays = Number.parseFloat( response.list[ind5].rain[ "3h" ] )
             } else {
              this.isSnowRainFourDays = false;
            }



            this.error = false;
            this.errorStr = (this.getWeatherForecastForCity(mesto.name)).cityName;
            this.date = new Date();

//              this.update(new Event(' '));
            this.thisSubj.next(true);

            clearInterval(this.interval);
            this.isSubmited = true;
//              this.pushNewWeatherForecast();

            return true;
      },
      (error) => {
        console.log(error);
        this.error = true;
        if (!error || !error.error || !error.error.message) {
          this.errorStr = 'unknown error';
        } else {
          this.errorStr = error.error.message;
        }
        console.log( "error" );


        clearInterval(this.interval);

      }
      );

  }

  clear() {
    clearInterval(this.interval);
  }


  subj: Subject<boolean> = new Subject<boolean>();
  public data: any;
  public options: any;
  update(event: Event) {
//    if (this.isSubmited === false) {
//      return;
//    }
    this.data = {
      labels: [], //'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10'],
      datasets: [
          {
              label: 'temp',
              data: [],
              borderColor: '#000FFF',
              tension: 0.5,
              responsive: true
          },
          {
            label: 'vlaga',
            data: [],
            tension: 0.3,
            borderColor: '#00FFFF',
            responsive: true
          },
          {
            label: 'dež sneg',
            data: [],
            borderColor: 'red',
            tension: 0.4,
            fontFace: 'underline',
          }
      ]
    };//create new data
    let index = 0;
    for (let m2 of  [this.mestoToday, this.mestoTodayMin,
      this.mestoAfterTomorrow, this.mestoTomorrowMin,
      this.mestoAfterTomorrow, this.mestoAfterTomorrowMin,
      this.mestoThreeDays, this.mestoThreeDaysMin,
      this.mestoFourDays, this.mestoFourDaysMin] )
    {
      this.data.labels.push(index);
      this.data.datasets[0].data.push(m2.temp);
      this.data.datasets[1].data.push(m2.humidity);
      if (  index / 2 === 0 ) {
        this.data.datasets[2].data.push(new Number(this.bSnowRainToday) );
      }
      else if (index / 2 === 1) {
        this.data.datasets[2].data.push(new Number (this.bSnowRainTomorow) );
      }
      else if (index / 2 === 2) {
        this.data.datasets[2].data.push(new Number(this.bSnowRainAfterTomorow) );
      } else if (index / 2 === 3) {
        this.data.datasets[2].data.push(new Number(this.bSnowRainThreeDays) );
      } else {
        this.data.datasets[2].data.push(new Number( this.bSnowRainFourDays) );
      }

      index += 1;
    }

    this.options = {
      title: {
          display: true,
          text: 'Vreme',
          fontSize: 16
      },
      legend: {
          position: 'bottom'
      }
    };

  }
  init() {
    if (this.isSubmited === false) {
      return;
    }
    this.data = {
      labels: ['0'],
      datasets: [
          {
              label: 'temp',
              data: [20],
              borderColor: '#000FFF',
              tension: 0.5,
              responsive: true
          },
          {
            label: 'vlaga',
            data: [60],
            tension: 0.3,
            borderColor: '#00FFFF',
            responsive: true
          },
          {
            label: 'dež sneg',
            data: [],
            borderColor: 'red',
            tension: 0.4,
            fontFace: 'underline',
          }
      ]
    };//create new data
    let index = 0;
/*
    for (let m2 of  [this.mestoToday, this.mestoAfterTomorrow, this.mestoAfterTomorrow, this.mestoThreeDays] )
    {
      this.data.labels.push(index);
      this.data.datasets[0].data.push(m2.temp);
      console.log(m2.temp);
      this.data.datasets[1].data.push(m2.humidity);
      index += 1;
    }
*/
// this data is for the chart
    this.options = {
      title: {
          display: true,
          text: 'Vreme',
          fontSize: 16, 
          temperature: 0.7,
          transparent: true
      },
      legend: {
          position: 'bottom'
      }
    };

  }



}

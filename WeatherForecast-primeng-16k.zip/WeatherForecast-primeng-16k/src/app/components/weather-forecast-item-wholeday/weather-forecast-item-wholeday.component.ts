import { Component, Input, OnDestroy, OnInit, Output, ViewChild } from '@angular/core';
import { ActivatedRoute, Data, Params } from '@angular/router';
import { Subscription } from 'rxjs';
import { Mesto } from 'src/app/models/city';
import { WeatherService } from 'src/app/services/weather.service';
import { formatNumber } from '@angular/common';

@Component({
  selector: 'app-weather-forecast-item-wholeday',
  templateUrl: './weather-forecast-item-wholeday.component.html',
  styleUrls: ['./weather-forecast-item-wholeday.component.scss']
})
export class WeatherForecastItemWholedayComponent implements OnInit, OnDestroy {

  monthNames: string [] = ['Januar', 'Februar', 'Marec', 'April', 'Maj',
  'Junij', 'Julij', 'Avgust', 'September', 'Oktober', 'November', 'December'];

  weekdayNames: string [] = ['Nedelja','Ponedeljek', 'Torek', 'Sreda', 'Četrtek', 'Petek', 'Sobota', 'Nedelja'];


  @Input( ) name1: string = '';
  @Input() name2: string = '';
  @Output() name12 = '';

  mesto0: Mesto = new Mesto('at@at.si', '', '0.0', '0.0', 'clear', 70, 'desc', 1.5, '10000');
  date0: Date = new Date();
  isSnowRain0: boolean = false;
  snowRain0: string = '0.15 l/m3';
  bSnowRain0: number = 0.0
  mesto0Min: Mesto = new Mesto('at@at.si', '', '0.0', '0.0', 'clear', 70, 'desc', 1.5, '10000');

  mesto1: Mesto = new Mesto('at@at.si', '', '0.0', '0.0', 'clear', 70, 'desc', 1.5, '10000');
  date1: Date = new Date();
  isSnowRain1: boolean = false;
  snowRain1: string = '0.15 l/m3';
  bSnowRain1: number = 0.0
  mesto1Min: Mesto = new Mesto('at@at.si', '', '0.0', '0.0', 'clear', 70, 'desc', 1.5, '10000');

  mesto2: Mesto = new Mesto('at@at.si', '', '0.0', '0.0', 'clear', 70, 'desc', 1.5, '10000');
  date2: Date = new Date();
  isSnowRain2: boolean = false;
  snowRain2: string = '0.15 l/m3';
  bSnowRain2: number = 0.0
  mesto2Min: Mesto = new Mesto('at@at.si', '', '0.0', '0.0', 'clear', 70, 'desc', 1.5, '10000');

  mesto3: Mesto = new Mesto('at@at.si', '', '0.0', '0.0', 'clear', 70, 'desc', 1.5, '10000');
  date3: Date = new Date();
  isSnowRain3: boolean = false;
  snowRain3: string = '0.15 l/m3';
  bSnowRain3: number = 0.0
  mesto3Min: Mesto = new Mesto('at@at.si', '', '0.0', '0.0', 'clear', 70, 'desc', 1.5, '10000');

  mesto4: Mesto = new Mesto('at@at.si', '', '0.0', '0.0', 'clear', 70, 'desc', 1.5, '10000');
  date4: Date = new Date();
  isSnowRain4: boolean = false;
  snowRain4: string = '0.15 l/m3';
  bSnowRain4: number = 0.0
  mesto4Min: Mesto = new Mesto('at@at.si', '', '0.0', '0.0', 'clear', 70, 'desc', 1.5, '10000');

  mesto5: Mesto = new Mesto('at@at.si', '', '0.0', '0.0', 'clear', 70, 'desc', 1.5, '10000');
  date5: Date = new Date();
  isSnowRain5: boolean = false;
  snowRain5: string = '0.15 l/m3';
  bSnowRain5: number = 0.0
  mesto5Min: Mesto = new Mesto('at@at.si', '', '0.0', '0.0', 'clear', 70, 'desc', 1.5, '10000');

  mesto6: Mesto = new Mesto('at@at.si', '', '0.0', '0.0', 'clear', 70, 'desc', 1.5, '10000');
  date6: Date = new Date();
  isSnowRain6: boolean = false;
  snowRain6: string = '0.15 l/m3';
  bSnowRain6: number = 0.0
  mesto6Min: Mesto = new Mesto('at@at.si', '', '0.0', '0.0', 'clear', 70, 'desc', 1.5, '10000');

  mesto7: Mesto = new Mesto('at@at.si', '', '0.0', '0.0', 'clear', 70, 'desc', 1.5, '10000');
  date7: Date = new Date();
  isSnowRain7: boolean = false;
  snowRain7: string = '0.15 l/m3';
  bSnowRain7: number = 0.0
  mesto7Min: Mesto = new Mesto('at@at.si', '', '0.0', '0.0', 'clear', 70, 'desc', 1.5, '10000');


  townname: string = '';
  interval: number = 5;

  subs: Subscription = new Subscription();

  constructor(public weatherForecast: WeatherService,
      public router: ActivatedRoute) {
    this.init();
  }


  clickToggle: boolean = false;
  doToggle() {
    this.clickToggle = !this.clickToggle;
  }

  
  ngOnInit(): void {

    this.subs = this.weatherForecast.thisSubj.subscribe(
      // Se narocimo, da bomo poslusali kdaj prejmemo objekt.
      (boola) => {
        if (boola === true)
        {
          this.name12 = this.weatherForecast.mestoToday.name;

          this.name1 = this.weatherForecast.mestoToday.name;
          this.name2 = this.weatherForecast.mestoToday.name;
          // dodali metodo za zapiši recepte
          let mesto = new Mesto('test@emg.si', 'name', '15', '15',
            'cloudy',20, 'no', 20, '1000');

          console.log(' response subscription je ');
          console.log( boola );

          this.update(new Event(''));

        }
      },
      (error: any) => {
        console.log('error component ' + error);
      }
    );

    this.router.params.subscribe((data: Params) => {
      this.townname = data['idname'];
      this.interval = +data['page'];
      this.createThisTownAndDay();
    });


  }

  ngOnDestroy(): void {
    this.subs.unsubscribe();
  }


  setPagesFromIndex(index: number) {
    if (index < 0 || index > 4) {
      return;
    }

    // First 3 hours
    this.mesto0 = new Mesto(this.weatherForecast.mestoToday.email,
      this.weatherForecast.responseQuery.city.name,
      ( +this.weatherForecast.responseQuery.list[(index * 8) + 0].main.temp_max - 273.16 ) + '',
      ( +this.weatherForecast.responseQuery.list[(index * 8) + 0].main.feels_like - 273.16 ) + '',
      this.weatherForecast.responseQuery.list[(index * 8) + 0].weather[0].main,
      +this.weatherForecast.responseQuery.list[(index * 8) + 0].main.humidity,
      this.weatherForecast.responseQuery.list[(index * 8) + 0].weather[0].description,
      +this.weatherForecast.responseQuery.list[(index * 8) + 0].wind.speed,
      this.weatherForecast.responseQuery.list[(index * 8) + 0].visibility + ''
    );

    this.mesto0Min = new Mesto(this.weatherForecast.mestoToday.email,
      this.weatherForecast.responseQuery.city.name,
      ( +this.weatherForecast.responseQuery.list[(index * 8) + 0].main.temp_min - 273.16 ) + '',
      ( +this.weatherForecast.responseQuery.list[(index * 8) + 0].main.feels_like - 273.16 ) + '',
      this.weatherForecast.responseQuery.list[(index * 8) + 0].weather[0].main,
      +this.weatherForecast.responseQuery.list[(index * 8) + 0].main.humidity,
      this.weatherForecast.responseQuery.list[(index * 8) + 0].weather[0].description,
      +this.weatherForecast.responseQuery.list[(index * 8) + 0].wind.speed,
      this.weatherForecast.responseQuery.list[(index * 8) + 0].visibility + ''
    );

    this.date0 = new Date();
    this.date0 = new Date( +this.weatherForecast.responseQuery.list[(index * 8) + 0].dt * 1000 );
    console.log(this.date0);

    if ( this.weatherForecast.responseQuery.list[(index * 8) + 0].snow !== undefined) {
      this.isSnowRain0 = true;
      let tmpMM: string = this.weatherForecast.responseQuery.list[(index * 8) + 0].snow[ "3h" ];
      this.snowRain0 = 'snowing' + tmpMM + ' lit/m2';
      this.bSnowRain0 = this.weatherForecast.responseQuery.list[(index * 8) + 0].snow[ "3h" ]
      console.log( this.weatherForecast.responseQuery.list[(index * 8) + 0].snow[ '3h' ] );
     } else if ( this.weatherForecast.responseQuery.list[(index * 8) + 0].rain !== undefined ) {
      this.isSnowRain0 = true;
      let tmpMM: string = this.weatherForecast.responseQuery.list[(index * 8) + 0].rain[ "3h" ];
      this.snowRain0 = 'raining' + tmpMM + ' lit/m2';
      this.bSnowRain0 = this.weatherForecast.responseQuery.list[(index * 8) + 0].rain[ "3h" ]
      console.log( this.weatherForecast.responseQuery.list[(index * 8) + 0].rain[ '3h' ] );
     } else {
      this.isSnowRain0 = false;
    }


    // Second 3 hours
    this.mesto1 = new Mesto(this.weatherForecast.mestoToday.email,
      this.weatherForecast.responseQuery.city.name,
      ( +this.weatherForecast.responseQuery.list[(index * 8) + 1].main.temp_max - 273.16 ) + '',
      ( +this.weatherForecast.responseQuery.list[(index * 8) + 1].main.feels_like - 273.16 ) + '',
      this.weatherForecast.responseQuery.list[(index * 8) + 1].weather[0].main,
      +this.weatherForecast.responseQuery.list[(index * 8) + 1].main.humidity,
      this.weatherForecast.responseQuery.list[(index * 8) + 1].weather[0].description,
      +this.weatherForecast.responseQuery.list[(index * 8) + 1].wind.speed,
      this.weatherForecast.responseQuery.list[(index * 8) + 1].visibility + ''
    );

    this.mesto1Min = new Mesto(this.weatherForecast.mestoToday.email,
      this.weatherForecast.responseQuery.city.name,
      ( +this.weatherForecast.responseQuery.list[(index * 8) + 1].main.temp_min - 273.16 ) + '',
      ( +this.weatherForecast.responseQuery.list[(index * 8) + 1].main.feels_like - 273.16 ) + '',
      this.weatherForecast.responseQuery.list[(index * 8) + 1].weather[0].main,
      +this.weatherForecast.responseQuery.list[(index * 8) + 1].main.humidity,
      this.weatherForecast.responseQuery.list[(index * 8) + 1].weather[0].description,
      +this.weatherForecast.responseQuery.list[(index * 8) + 1].wind.speed,
      this.weatherForecast.responseQuery.list[(index * 8) + 1].visibility + ''
    );

    this.date1 = new Date();
//    this.date1.setDate( +this.weatherForecast.responseQuery.list[(index * 8) + 1].dt );
    this.date1 = new Date( +this.weatherForecast.responseQuery.list[(index * 8) + 1].dt * 1000 );
    console.log(this.date1);

    if ( this.weatherForecast.responseQuery.list[(index * 8) + 1].snow !== undefined) {
      this.isSnowRain1 = true;
      let tmpMM: string = this.weatherForecast.responseQuery.list[(index * 8) + 1].snow[ "3h" ];
      this.snowRain1 = 'snowing' + tmpMM + ' lit/m2';
      this.bSnowRain1 = this.weatherForecast.responseQuery.list[(index * 8) + 1].snow[ "3h" ];
      console.log( this.weatherForecast.responseQuery.list[(index * 8) + 1].snow[ '3h' ] );
     } else if ( this.weatherForecast.responseQuery.list[(index * 8) + 1].rain !== undefined ) {
      this.isSnowRain1 = true;
      let tmpMM: string = this.weatherForecast.responseQuery.list[(index * 8) + 1].rain[ "3h" ];
      this.snowRain1 = 'raining' + tmpMM + ' lit/m2';
      this.bSnowRain1 = this.weatherForecast.responseQuery.list[(index * 8) + 1].rain[ "3h" ];
      console.log( this.weatherForecast.responseQuery.list[(index * 8) + 1].rain[ '3h' ] );
     } else {
      this.isSnowRain1 = false;
    }


    // Third 3 hours
    this.mesto2 = new Mesto(this.weatherForecast.mestoToday.email,
      this.weatherForecast.responseQuery.city.name,
      ( +this.weatherForecast.responseQuery.list[(index * 8) + 2].main.temp_max - 273.16 ) + '',
      ( +this.weatherForecast.responseQuery.list[(index * 8) + 2].main.feels_like - 273.16 ) + '',
      this.weatherForecast.responseQuery.list[(index * 8) + 2].weather[0].main,
      +this.weatherForecast.responseQuery.list[(index * 8) + 2].main.humidity,
      this.weatherForecast.responseQuery.list[(index * 8) + 2].weather[0].description,
      +this.weatherForecast.responseQuery.list[(index * 8) + 2].wind.speed,
      this.weatherForecast.responseQuery.list[(index * 8) + 2].visibility + ''
    );

    this.mesto2Min = new Mesto(this.weatherForecast.mestoToday.email,
      this.weatherForecast.responseQuery.city.name,
      ( +this.weatherForecast.responseQuery.list[(index * 8) + 2].main.temp_min - 273.16 ) + '',
      ( +this.weatherForecast.responseQuery.list[(index * 8) + 2].main.feels_like - 273.16 ) + '',
      this.weatherForecast.responseQuery.list[(index * 8) + 2].weather[0].main,
      +this.weatherForecast.responseQuery.list[(index * 8) + 2].main.humidity,
      this.weatherForecast.responseQuery.list[(index * 8) + 2].weather[0].description,
      +this.weatherForecast.responseQuery.list[(index * 8) + 2].wind.speed,
      this.weatherForecast.responseQuery.list[(index * 8) + 2].visibility + ''
    );

    this.date2 = new Date();
    this.date2 = new Date( +this.weatherForecast.responseQuery.list[(index * 8) + 2].dt * 1000 );
    console.log(this.date2);

    if ( this.weatherForecast.responseQuery.list[(index * 8) + 2].snow !== undefined) {
      this.isSnowRain2 = true;
      let tmpMM: string = this.weatherForecast.responseQuery.list[(index * 8) + 2].snow[ "3h" ];
      this.snowRain2 = 'snowing' + tmpMM + ' lit/m2';
      this.bSnowRain2 = this.weatherForecast.responseQuery.list[(index * 8) + 2].snow[ "3h" ];
      console.log( this.weatherForecast.responseQuery.list[(index * 8) + 2].snow[ '3h' ] );
     } else if ( this.weatherForecast.responseQuery.list[(index * 8) + 2].rain !== undefined ) {
      this.isSnowRain2 = true;
      let tmpMM: string = this.weatherForecast.responseQuery.list[(index * 8) + 2].rain[ "3h" ];
      this.snowRain2 = 'raining' + tmpMM + ' lit/m2';
      this.bSnowRain2 = this.weatherForecast.responseQuery.list[(index * 8) + 2].rain[ "3h" ];
      console.log( this.weatherForecast.responseQuery.list[(index * 8) + 2].rain[ '3h' ] );
     } else {
      this.isSnowRain2 = false;
    }


    // Fourth 3 hours
    this.mesto3 = new Mesto(this.weatherForecast.mestoToday.email,
      this.weatherForecast.responseQuery.city.name,
      ( +this.weatherForecast.responseQuery.list[(index * 8) + 3].main.temp_max - 273.16 ) + '',
      ( +this.weatherForecast.responseQuery.list[(index * 8) + 3].main.feels_like - 273.16 ) + '',
      this.weatherForecast.responseQuery.list[(index * 8) + 3].weather[0].main,
      +this.weatherForecast.responseQuery.list[(index * 8) + 3].main.humidity,
      this.weatherForecast.responseQuery.list[(index * 8) + 3].weather[0].description,
      +this.weatherForecast.responseQuery.list[(index * 8) + 3].wind.speed,
      this.weatherForecast.responseQuery.list[(index * 8) + 3].visibility + ''
    );

    this.mesto3Min = new Mesto(this.weatherForecast.mestoToday.email,
      this.weatherForecast.responseQuery.city.name,
      ( +this.weatherForecast.responseQuery.list[(index * 8) + 3].main.temp_min - 273.16 ) + '',
      ( +this.weatherForecast.responseQuery.list[(index * 8) + 3].main.feels_like - 273.16 ) + '',
      this.weatherForecast.responseQuery.list[(index * 8) + 3].weather[0].main,
      +this.weatherForecast.responseQuery.list[(index * 8) + 3].main.humidity,
      this.weatherForecast.responseQuery.list[(index * 8) + 3].weather[0].description,
      +this.weatherForecast.responseQuery.list[(index * 8) + 3].wind.speed,
      this.weatherForecast.responseQuery.list[(index * 8) + 3].visibility + ''
    );

    this.date3 = new Date();
    this.date3 = new Date( +this.weatherForecast.responseQuery.list[(index * 8) + 3].dt * 1000 );
    console.log(this.date3);

    if ( this.weatherForecast.responseQuery.list[(index * 8) + 3].snow !== undefined) {
      this.isSnowRain3 = true;
      let tmpMM: string = this.weatherForecast.responseQuery.list[(index * 8) + 3].snow[ "3h" ];
      this.snowRain3 = 'snowing' + tmpMM + ' lit/m2';
      this.bSnowRain3 = this.weatherForecast.responseQuery.list[(index * 8) + 3].snow[ "3h" ];
      console.log( this.weatherForecast.responseQuery.list[(index * 8) + 3].snow[ '3h' ] );
     } else if ( this.weatherForecast.responseQuery.list[(index * 8) + 3].rain !== undefined ) {
      this.isSnowRain3 = true;
      let tmpMM: string = this.weatherForecast.responseQuery.list[(index * 8) + 3].rain[ "3h" ];
      this.snowRain3 = 'raining' + tmpMM + ' lit/m2';
      this.bSnowRain3 = this.weatherForecast.responseQuery.list[(index * 8) + 3].rain[ "3h" ];
      console.log( this.weatherForecast.responseQuery.list[(index * 8) + 3].rain[ '3h' ] );
     } else {
      this.isSnowRain3 = false;
    }


    // Fifth 3 hours
    this.mesto4 = new Mesto(this.weatherForecast.mestoToday.email,
      this.weatherForecast.responseQuery.city.name,
      ( +this.weatherForecast.responseQuery.list[(index * 8) + 4].main.temp_max - 273.16 ) + '',
      ( +this.weatherForecast.responseQuery.list[(index * 8) + 4].main.feels_like - 273.16 ) + '',
      this.weatherForecast.responseQuery.list[(index * 8) + 4].weather[0].main,
      +this.weatherForecast.responseQuery.list[(index * 8) + 4].main.humidity,
      this.weatherForecast.responseQuery.list[(index * 8) + 4].weather[0].description,
      +this.weatherForecast.responseQuery.list[(index * 8) + 4].wind.speed,
      this.weatherForecast.responseQuery.list[(index * 8) + 4].visibility + ''
    );

    this.mesto4Min = new Mesto(this.weatherForecast.mestoToday.email,
      this.weatherForecast.responseQuery.city.name,
      ( +this.weatherForecast.responseQuery.list[(index * 8) + 4].main.temp_min - 273.16 ) + '',
      ( +this.weatherForecast.responseQuery.list[(index * 8) + 4].main.feels_like - 273.16 ) + '',
      this.weatherForecast.responseQuery.list[(index * 8) + 4].weather[0].main,
      +this.weatherForecast.responseQuery.list[(index * 8) + 4].main.humidity,
      this.weatherForecast.responseQuery.list[(index * 8) + 4].weather[0].description,
      +this.weatherForecast.responseQuery.list[(index * 8) + 4].wind.speed,
      this.weatherForecast.responseQuery.list[(index * 8) + 4].visibility + ''
    );

    this.date4 = new Date();
    this.date4 = new Date( +this.weatherForecast.responseQuery.list[(index * 8) + 4].dt * 1000 );
    console.log(this.date4);

    if ( this.weatherForecast.responseQuery.list[(index * 8) + 4].snow !== undefined) {
      this.isSnowRain4 = true;
      let tmpMM: string = this.weatherForecast.responseQuery.list[(index * 8) + 4].snow[ "3h" ];
      this.snowRain4 = 'snowing' + tmpMM + ' lit/m2';
      this.bSnowRain4 = this.weatherForecast.responseQuery.list[(index * 8) + 4].snow[ "3h" ];
      console.log( this.weatherForecast.responseQuery.list[(index * 8) + 4].snow[ '3h' ] );
     } else if ( this.weatherForecast.responseQuery.list[(index * 8) + 4].rain !== undefined ) {
      this.isSnowRain4 = true;
      let tmpMM: string = this.weatherForecast.responseQuery.list[(index * 8) + 4].rain[ "3h" ];
      this.snowRain4 = 'raining' + tmpMM + ' lit/m2';
      this.bSnowRain4 = this.weatherForecast.responseQuery.list[(index * 8) + 4].rain[ "3h" ];
      console.log( this.weatherForecast.responseQuery.list[(index * 8) + 4].rain[ '3h' ] );
     } else {
      this.isSnowRain4 = false;
    }


    // Sixth 3 hours
    this.mesto5 = new Mesto(this.weatherForecast.mestoToday.email,
      this.weatherForecast.responseQuery.city.name,
      ( +this.weatherForecast.responseQuery.list[(index * 8) + 5].main.temp_max - 273.16 ) + '',
      ( +this.weatherForecast.responseQuery.list[(index * 8) + 5].main.feels_like - 273.16 ) + '',
      this.weatherForecast.responseQuery.list[(index * 8) + 5].weather[0].main,
      +this.weatherForecast.responseQuery.list[(index * 8) + 5].main.humidity,
      this.weatherForecast.responseQuery.list[(index * 8) + 5].weather[0].description,
      +this.weatherForecast.responseQuery.list[(index * 8) + 5].wind.speed,
      this.weatherForecast.responseQuery.list[(index * 8) + 5].visibility + ''
    );

    this.mesto5Min = new Mesto(this.weatherForecast.mestoToday.email,
      this.weatherForecast.responseQuery.city.name,
      ( +this.weatherForecast.responseQuery.list[(index * 8) + 5].main.temp_min - 273.16 ) + '',
      ( +this.weatherForecast.responseQuery.list[(index * 8) + 5].main.feels_like - 273.16 ) + '',
      this.weatherForecast.responseQuery.list[(index * 8) + 5].weather[0].main,
      +this.weatherForecast.responseQuery.list[(index * 8) + 5].main.humidity,
      this.weatherForecast.responseQuery.list[(index * 8) + 5].weather[0].description,
      +this.weatherForecast.responseQuery.list[(index * 8) + 5].wind.speed,
      this.weatherForecast.responseQuery.list[(index * 8) + 5].visibility + ''
    );

    this.date5 = new Date();
    this.date5 = new Date( +this.weatherForecast.responseQuery.list[(index * 8) + 5].dt * 1000 );
    console.log(this.date5);

    if ( this.weatherForecast.responseQuery.list[(index * 8) + 5].snow !== undefined) {
      this.isSnowRain5 = true;
      let tmpMM: string = this.weatherForecast.responseQuery.list[(index * 8) + 5].snow[ "3h" ];
      this.snowRain5 = 'snowing' + tmpMM + ' lit/m2';
      this.bSnowRain5 = this.weatherForecast.responseQuery.list[(index * 8) + 5].snow[ "3h" ];
      console.log( this.weatherForecast.responseQuery.list[(index * 8) + 5].snow[ '3h' ] );
     } else if ( this.weatherForecast.responseQuery.list[(index * 8) + 5].rain !== undefined ) {
      this.isSnowRain5 = true;
      let tmpMM: string = this.weatherForecast.responseQuery.list[(index * 8) + 5].rain[ "3h" ];
      this.snowRain5 = 'raining' + tmpMM + ' lit/m2';
      this.bSnowRain5 = this.weatherForecast.responseQuery.list[(index * 8) + 5].rain[ "3h" ];
      console.log( this.weatherForecast.responseQuery.list[(index * 8) + 5].rain[ '3h' ] );
     } else {
      this.isSnowRain5 = false;
    }

    // Seventh 3 hours
    this.mesto6 = new Mesto(this.weatherForecast.mestoToday.email,
      this.weatherForecast.responseQuery.city.name,
      ( +this.weatherForecast.responseQuery.list[(index * 8) + 6].main.temp_max - 273.16 ) + '',
      ( +this.weatherForecast.responseQuery.list[(index * 8) + 6].main.feels_like - 273.16 ) + '',
      this.weatherForecast.responseQuery.list[(index * 8) + 6].weather[0].main,
      +this.weatherForecast.responseQuery.list[(index * 8) + 6].main.humidity,
      this.weatherForecast.responseQuery.list[(index * 8) + 6].weather[0].description,
      +this.weatherForecast.responseQuery.list[(index * 8) + 6].wind.speed,
      this.weatherForecast.responseQuery.list[(index * 8) + 6].visibility + ''
    );

    this.mesto6Min = new Mesto(this.weatherForecast.mestoToday.email,
      this.weatherForecast.responseQuery.city.name,
      ( +this.weatherForecast.responseQuery.list[(index * 8) + 6].main.temp_min - 273.16 ) + '',
      ( +this.weatherForecast.responseQuery.list[(index * 8) + 6].main.feels_like - 273.16 ) + '',
      this.weatherForecast.responseQuery.list[(index * 8) + 6].weather[0].main,
      +this.weatherForecast.responseQuery.list[(index * 8) + 6].main.humidity,
      this.weatherForecast.responseQuery.list[(index * 8) + 6].weather[0].description,
      +this.weatherForecast.responseQuery.list[(index * 8) + 6].wind.speed,
      this.weatherForecast.responseQuery.list[(index * 8) + 6].visibility + ''
    );

    this.date6 = new Date();
    this.date6 = new Date( +this.weatherForecast.responseQuery.list[(index * 8) + 6].dt * 1000 );
    console.log(this.date6);

    if ( this.weatherForecast.responseQuery.list[(index * 8) + 6].snow !== undefined) {
      this.isSnowRain6 = true;
      let tmpMM: string = this.weatherForecast.responseQuery.list[(index * 8) + 6].snow[ "3h" ];
      this.snowRain6 = 'snowing' + tmpMM + ' lit/m2';
      this.bSnowRain6 = this.weatherForecast.responseQuery.list[(index * 8) + 6].snow[ "3h" ];
      console.log( this.weatherForecast.responseQuery.list[(index * 8) + 6].snow[ '3h' ] );
     } else if ( this.weatherForecast.responseQuery.list[(index * 8) + 6].rain !== undefined ) {
      this.isSnowRain6 = true;
      let tmpMM: string = this.weatherForecast.responseQuery.list[(index * 8) + 6].rain[ "3h" ];
      this.snowRain6 = 'raining' + tmpMM + ' lit/m2';
      this.bSnowRain6 = this.weatherForecast.responseQuery.list[(index * 8) + 6].rain[ "3h" ];
      console.log( this.weatherForecast.responseQuery.list[(index * 8) + 6].rain[ '3h' ] );
     } else {
      this.isSnowRain6 = false;
    }


    // Eight 3 hours
    this.mesto7 = new Mesto(this.weatherForecast.mestoToday.email,
      this.weatherForecast.responseQuery.city.name,
      ( +this.weatherForecast.responseQuery.list[(index * 8) + 7].main.temp_max - 273.16 ) + '',
      ( +this.weatherForecast.responseQuery.list[(index * 8) + 7].main.feels_like - 273.16 ) + '',
      this.weatherForecast.responseQuery.list[(index * 8) + 7].weather[0].main,
      +this.weatherForecast.responseQuery.list[(index * 8) + 7].main.humidity,
      this.weatherForecast.responseQuery.list[(index * 8) + 7].weather[0].description,
      +this.weatherForecast.responseQuery.list[(index * 8) + 7].wind.speed,
      this.weatherForecast.responseQuery.list[(index * 8) + 7].visibility + ''
    );

    this.mesto7Min = new Mesto(this.weatherForecast.mestoToday.email,
      this.weatherForecast.responseQuery.city.name,
      ( +this.weatherForecast.responseQuery.list[(index * 8) + 7].main.temp_min - 273.16 ) + '',
      ( +this.weatherForecast.responseQuery.list[(index * 8) + 7].main.feels_like - 273.16 ) + '',
      this.weatherForecast.responseQuery.list[(index * 8) + 7].weather[0].main,
      +this.weatherForecast.responseQuery.list[(index * 8) + 7].main.humidity,
      this.weatherForecast.responseQuery.list[(index * 8) + 7].weather[0].description,
      +this.weatherForecast.responseQuery.list[(index * 8) + 7].wind.speed,
      this.weatherForecast.responseQuery.list[(index * 8) + 7].visibility + ''
    );

    this.date7 = new Date();
    this.date7 = new Date( +this.weatherForecast.responseQuery.list[(index * 8) + 7].dt * 1000 );
    console.log(this.date7);

    if ( this.weatherForecast.responseQuery.list[(index * 8) + 7].snow !== undefined) {
      this.isSnowRain7 = true;
      let tmpMM: string = this.weatherForecast.responseQuery.list[(index * 8) + 7].snow[ "3h" ];
      this.snowRain7 = 'snowing' + tmpMM + ' lit/m2';
      this.bSnowRain7 = this.weatherForecast.responseQuery.list[(index * 8) + 7].snow[ "3h" ];
      console.log( this.weatherForecast.responseQuery.list[(index * 8) + 7].snow[ '3h' ] );
     } else if ( this.weatherForecast.responseQuery.list[(index * 8) + 7].rain !== undefined ) {
      this.isSnowRain7 = true;
      let tmpMM: string = this.weatherForecast.responseQuery.list[(index * 8) + 7].rain[ "3h" ];
      this.snowRain7 = 'raining' + tmpMM + ' lit/m2';
      this.bSnowRain7 = this.weatherForecast.responseQuery.list[(index * 8) + 7].rain[ "3h" ];
      console.log( this.weatherForecast.responseQuery.list[(index * 8) + 7].rain[ '3h' ] );
     } else {
      this.isSnowRain7 = false;
    }

  }

  createThisTownAndDay() {
    this.weatherForecast.getForecastByName( this.townname );

    if ( this.weatherForecast.responseQuery === null ) {
      return;
    }

    // Only five possible days, incrementing index
    switch (this.interval) {
      case 0:
      {
        this.setPagesFromIndex(0);
        break;
      }
      case 1:
      {
        this.setPagesFromIndex(1);
        break;
      }
      case 2:
      {
        this.setPagesFromIndex(2);
        break;
      }
      case 3:
      {
        this.setPagesFromIndex(3);
        break;
      }
      case 4:
      {
        this.setPagesFromIndex(4);
        break;
      }
      default :
      {
        // Default first day
        this.setPagesFromIndex(0);
      }
    }
  }




  public data: any;
  public options: any;
  update(event: Event) {
//    if (this.weatherForecast.isSubmited) {
    this.weatherForecast.update(new Event(''));

    this.init();

    for (let el = 0; el < 40; el++) {
      this.data.labels.push(el + '');
      this.data.datasets[0].data.push( this.weatherForecast.responseQuery.list[el].main.temp_max - 273.16);
      this.data.datasets[1].data.push(this.weatherForecast.responseQuery.list[el].main.humidity);

      if ( this.weatherForecast.responseQuery.list[el].snow !== undefined) {
        let tmpMM: string = this.weatherForecast.responseQuery.list[el].snow[ "3h" ];
        this.data.datasets[2].data.push( tmpMM );

      } else if ( this.weatherForecast.responseQuery.list[el].rain !== undefined ) {
        let tmpMM: string = this.weatherForecast.responseQuery.list[el].rain[ "3h" ];
        this.data.datasets[2].data.push( tmpMM );

      } else {
        this.data.datasets[2].data.push(0.0 );
      }
        this.options = this.weatherForecast.options;
    }
    console.log(this.data);
    this.weatherForecast.data = this.data;
//    }
  }
  init() {
    this.data = {
      labels: [],
      datasets: [
          {
              label: 'temp',
              data: [],
              borderColor: '#000FFF',
              tension: 0.5,
              fontFace: 'bold',
          },
          {
            label: 'vlaga',
            data: [],
            tension: 0.3,
            borderColor: '#00FFFF',
            fontFace: 'italic',
          },
          {
            label: 'dež sneg',
            data: [],
            borderColor: 'red',
            tension: 0.4,
            fontFace: 'underline',
          }
      ]
    };//create new data

    this.options = {
      title: {
          display: true,
          text: 'Vreme',
          fontSize: 16,
      },
      legend: {
          position: 'top',
          fontFace: 'bold',
          fontColor: '#FF0F00',
      }
    };

}


formatNumber(num: number, loc: string, digits: string): string {
  return formatNumber(num, loc, digits);
}


}

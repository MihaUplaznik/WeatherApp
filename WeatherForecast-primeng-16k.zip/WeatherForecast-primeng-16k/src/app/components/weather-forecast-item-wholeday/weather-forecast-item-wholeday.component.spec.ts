import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WeatherForecastItemWholedayComponent } from './weather-forecast-item-wholeday.component';

describe('WeatherForecastItemWholedayComponent', () => {
  let component: WeatherForecastItemWholedayComponent;
  let fixture: ComponentFixture<WeatherForecastItemWholedayComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WeatherForecastItemWholedayComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(WeatherForecastItemWholedayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

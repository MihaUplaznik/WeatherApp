import {Component, OnDestroy, OnInit} from '@angular/core';
import { Subscription } from 'rxjs';
import { Mesto } from 'src/app/models/city';
import {WeatherService} from '../../services/weather.service';
import { formatNumber } from '@angular/common';


@Component({
  selector: 'app-weather-forecast',
  templateUrl: './weather-forecast.component.html',
  styleUrls: ['./weather-forecast.component.scss']
})
export class WeatherForecastComponent implements OnInit, OnDestroy {
  monthNames: string [] = ['Januar', 'Februar', 'Marec', 'April', 'Maj',
  'Junij', 'Julij', 'Avgust', 'September', 'Oktober', 'November', 'December'];

  weekdayNames: string [] = ['Nedelja','Ponedeljek', 'Torek', 'Sreda', 'Četrtek', 'Petek', 'Sobota', 'Nedelja'];

  subs : any = new Subscription();

  constructor(public weatherService: WeatherService) {
  }


  clickToggle: boolean = false;
  doToggle() {
    this.clickToggle = !this.clickToggle;
  }

  ngOnInit() {
    console.log(this.weatherService.getWeatherForecastForCity('Maribor'));
    this.subs = this.weatherService.thisSubj.subscribe(
      // Se narocimo, da bomo poslusali kdaj prejmemo objekt.
      (boola) => {
      if (boola === true)
      {
        // dodali metodo za zapiši recepte
        let mesto = new Mesto('test@emg.si', 'name', '15', '15',
          'cloudy',20, 'no', 20, '1000');

        console.log(' response subscription je ');
        console.log( boola );

        this.weatherService.data.labels.push(0);
        this.weatherService.data.datasets[0].data.push(+this.weatherService.mestoToday.temp);
        this.weatherService.data.datasets[1].data.push(this.weatherService.mestoToday.humidity);
        this.weatherService.data.datasets[2].data.push(this.weatherService.bSnowRainToday);

        this.weatherService.data.labels.push(1);
        this.weatherService.data.datasets[0].data.push(+this.weatherService.mestoTomorrow.temp);
        this.weatherService.data.datasets[1].data.push(this.weatherService.mestoTomorrow.humidity);
        this.weatherService.data.datasets[2].data.push(this.weatherService.bSnowRainTomorow);

        this.weatherService.data.labels.push(2);
        this.weatherService.data.datasets[0].data.push(+this.weatherService.mestoAfterTomorrow.temp);
        this.weatherService.data.datasets[1].data.push(this.weatherService.mestoAfterTomorrow.humidity);
        this.weatherService.data.datasets[2].data.push(this.weatherService.bSnowRainAfterTomorow);

        this.weatherService.data.labels.push(3);
        this.weatherService.data.datasets[0].data.push(+this.weatherService.mestoThreeDays.temp);
        this.weatherService.data.datasets[1].data.push(this.weatherService.mestoThreeDays.humidity);
        this.weatherService.data.datasets[2].data.push(this.weatherService.bSnowRainThreeDays);
      }
      },
      (error: any) => {
        console.log(error);
      }
    );

  }

  ngOnDestroy(): void {
      this.subs.unsubscribe();
  }

  log(cityName: string) {
    console.log(this.weatherService.getWeatherForecastForCity(cityName));
  }

  formatNumber(num: number, loc: string, digits: string): string {
    return formatNumber(num, loc, digits);
  }
}

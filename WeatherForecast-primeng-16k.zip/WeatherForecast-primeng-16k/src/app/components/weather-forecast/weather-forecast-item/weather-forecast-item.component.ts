import { Component, OnDestroy, OnInit, Output, ViewChild } from '@angular/core';
import { Observable, Subject, Subscription } from 'rxjs';
import { Mesto } from 'src/app/models/city';
import { WeatherForecast2, WeatherService } from 'src/app/services/weather.service';
import { formatNumber } from '@angular/common';


@Component({
  selector: 'app-weather-forecast-item',
  templateUrl: './weather-forecast-item.component.html',
  styleUrls: ['./weather-forecast-item.component.scss']
})
export class WeatherForecastItemComponent implements OnInit, OnDestroy {
  monthNames: string [] = ['Januar', 'Februar', 'Marec', 'April', 'Maj',
  'Junij', 'Julij', 'Avgust', 'September', 'Oktober', 'November', 'December'];

  weekdayNames: string [] = ['Nedelja','Ponedeljek', 'Torek', 'Sreda', 'Četrtek', 'Petek', 'Sobota', 'Nedelja'];

  subs: Subscription = new Subscription();
  @Output() name12: string = '';
  @Output() name3: string = 'Ljubljana';
  forecasts: any[]  = [];

  constructor(public weatherForecast: WeatherService) {
    this.init();
  }


  clickToggle: boolean = false;
  doToggle(index: number) {
    for (let el of this.forecasts) {
      el.clickToggle = false;
    }
    if (index >= 0 && index < this.forecasts.length) {
      this.forecasts[index].clickToggle = true;
    }
  }

  
  ngOnInit(): void {

    this.subs = this.weatherForecast.thisSubj.subscribe(
      // Se narocimo, da bomo poslusali kdaj prejmemo objekt.
      (boola) => {
        if (boola === true)
        {
          this.name12 =  this.weatherForecast.mestoToday.name ;
          // dodali metodo za zapiši recepte
          let mesto = new Mesto('test@emg.si', this.name12[ this.name12.length - 1 ], '15', '15',
            'cloudy',20, 'no', 20, '1000');

          this.forecasts = this.weatherForecast.weatherForecast2;
          console.log( this.forecasts.length );          
          console.log(' Element vremena je ');

          this.update(new Event(''));

        }
      },
      (error: any) => {
        console.log('error component ' + error);
      }
    );

  }

  ngOnDestroy(): void {
    this.subs.unsubscribe();
  }


  public data: any;
  public options: any;
  update(event: Event) {
//    if (this.weatherForecast.isSubmited) {
    this.weatherForecast.update(new Event(''));
      this.data = this.weatherForecast.data;

      this.options = this.weatherForecast.options;
//    }
  }
  init() {
    this.data = {
      labels: ['F'],
      datasets: [
          {
              label: 'temp',
              data: [10],
              borderColor: '#000FFF',
              tension: 0.5
          },
          {
            label: 'vlaga',
            data: [82],
            tension: 0.3,
            borderColor: '#00FFFF'
          },
          {
            label: 'dež sneg',
            data: [],
            borderColor: 'red',
            tension: 0.4,
            fontFace: 'underline',
          }
      ]
    };//create new data

    this.options = {
      title: {
          display: true,
          text: 'Vreme',
          fontSize: 16
      },
      legend: {
          position: 'bottom'
      }
    };

  }

  formatNumber(num: number, loc: string, digits: string): string {
    return formatNumber(num, loc, digits);
  }

}

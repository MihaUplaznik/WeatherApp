import { Directive } from '@angular/core';

@Directive({
  selector: '[appBackgroundDirective]'
})
export class BackgroundDirectiveDirective {

  constructor() { }

}

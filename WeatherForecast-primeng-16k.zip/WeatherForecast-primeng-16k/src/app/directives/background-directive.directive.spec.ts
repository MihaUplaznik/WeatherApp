import { BackgroundDirectiveDirective } from './background-directive.directive';

describe('BackgroundDirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new BackgroundDirectiveDirective();
    expect(directive).toBeTruthy();
  });
});

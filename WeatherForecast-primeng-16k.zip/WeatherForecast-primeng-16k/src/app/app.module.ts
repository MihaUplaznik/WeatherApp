import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { ChartModule } from 'primeng/chart';

import {AppRoutingModule} from './app-routing.module';
import {AppComponent} from './app.component';
import {WeatherForecastComponent} from './components/weather-forecast/weather-forecast.component';
import { WeatherForecastItemComponent } from './components/weather-forecast/weather-forecast-item/weather-forecast-item.component';
import { RegisterComponent } from './auth/register/register.component';
import { SigninComponent } from './auth/signin/signin.component';
import { RetrieveComponent } from './auth/retrieve/retrieve.component';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { AuthService } from './auth/auth.service';
import { WeatherService } from './services/weather.service';
import { WeatherForecastItemWholedayComponent } from './components/weather-forecast-item-wholeday/weather-forecast-item-wholeday.component';
import { BackgroundDirectiveDirective } from './directives/background-directive.directive';




export function MyLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http);
}

@NgModule({
  declarations: [
    AppComponent,
    WeatherForecastComponent,
    WeatherForecastItemComponent,
    RegisterComponent,
    SigninComponent,
    RetrieveComponent,
    WeatherForecastItemWholedayComponent,
    BackgroundDirectiveDirective
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: (MyLoaderFactory),
        deps: [HttpClient]
      }
     }),
    ChartModule
  ],
  providers: [AuthService, WeatherService],
  bootstrap: [AppComponent]
})
export class AppModule {
}

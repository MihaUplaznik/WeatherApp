export const environment = {
  production: true,
  firebaseKey: 'AIzaSyA-0im8wOi5xJjd38OmXCrrAjql9pW8MTQ'

};
